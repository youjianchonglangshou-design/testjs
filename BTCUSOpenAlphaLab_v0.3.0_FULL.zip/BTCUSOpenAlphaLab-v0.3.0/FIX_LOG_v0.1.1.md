# BTC US Open Alpha Lab v0.1.1 — 修正紀錄

日期：2026-10-09

## 修正
- 修復 `alpha_lab/data.py` 的 BTC 報酬欄位名稱錯誤：`ret_12/48/96` 統一為模型預期的 `btc_ret_12/48/96`，解決 `KeyError: btc_ret_12`。
- `tests/test_alpha.py` 增加欄位契約回歸斷言。
- 程式、指令檔及 README 版本更新為 v0.1.1。

## 真實回測
- 2023-01 至 2026-03 BTCUSDT 5M 歷史資料：341,552 根；QQQ 資料 154,315 根。
- 訓練結束：2024-12-31；驗證結束：2025-06-30；樣本外：2025-07 起至可得資料末日。
- 來源為 Binance 公開行情及第三方社群 QQQ，不是官方 SIP；報告需檢驗共同樣本與交易成本。
- 詳細數值：`reports/REPORT.md`、`reports/latest.json`、`reports/data_quality.json`、`reports/events.csv`。
- 報告不等於確定的未來報酬。基準模型對照、時間穩健性、盤前資料可用性仍需做後續驗證。

## 操作
- 已有歷史快取，可直接 `py -3 -m alpha_lab run --start 2023-01 --end 2026-03`，不需重下載。
- 一鍵啟動仍可使用 `RUN_WINDOWS.bat`。
- 發布 ZIP 僅包含程式、測試及本次報告；大型 `data/cache` 歷史資料繼續保留在原本專案資料夾。
