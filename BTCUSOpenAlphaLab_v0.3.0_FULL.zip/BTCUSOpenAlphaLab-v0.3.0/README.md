# BTC US Open Alpha Lab v0.3.0

**獨立於 BTCFLOWPulse 的美股開盤 BTC 歷史研究實作**。核心預測：美東 09:30 正式開盤後，到 11:30 之間 BTC 的方向。預測時點為 09:15、09:35、10:00 美東時間，冬夏令自動調整。

## 狀態與界線

- ✅ 已實作：下載器、QQQ 與 BTC 時間校準、NYSE 交易日、避免 K 線偷看未來、3 個預測時點、M1/M2/M3、概率校準、時間順序樣本外測試、模擬交易、報表網頁、單元測試。
- ✅ v0.2.0 已新增：M0/M1/M2/M3 共用同一批完整樣本，2024 H2／2025／2026 Q1 滾動驗證、成對差異信賴區間、McNemar 檢定、改版網頁與逐日預測 CSV。
- ⚠️ **真實資料必須下載成功，才能產生真實回測。** 開源 QQQ 資料並非官方 SIP，有可能不齊、格式混用，已針對缺漏資料採取排除而非填假值。
- ⚠️ `smoke` 產生的**全部是合成測試資料**，僅證明流程能跑，不可以當勝率。
- ❌ v0.3.0 尚未完成：Pionex 即時連接、TradingView 即時行情、資金費率與 OI 資料、每月 walk-forward 再訓練、實際下單、Cloudflare Worker、和 BTCFLOWPulse 同期對決。

## 需要

Python 3.10+、可連線 GitHub Raw 與 Binance 公開歷史資料的電腦或雲端環境。研究引擎本身不依賴 Remote Desktop Commander；本次修復與回測是經授權遠端在使用者電腦執行。資料來源為 Binance 公開資料及 GitHub 的 QQQ 社群資料。

## GitHub Pages 即時前向試驗（v0.3.0）

新增 `docs/index.html` 前向預測主頁、`docs/research.html` 歷史驗證，以及 GitHub Actions 交易日快照。先建立名為 BTCUSOpenAlphaLab 的公開 GitHub 倉庫；上傳完整程式後在 Settings → Pages 選擇 GitHub Actions。歷史模型未證實穩定獲利，詳情參閱 `RELEASE_v0.3.0.md`。

## 操作

```bash
python -m pip install -r requirements.txt
python -m pytest -q
python -m alpha_lab download --start 2023-01 --end 2026-03
python -m alpha_lab run --start 2023-01 --end 2026-03
python -m alpha_lab robustness
python -m http.server 8000
```

打開 `http://127.0.0.1:8000/web/`。原始回測結果放在 `reports/latest.json`、`reports/REPORT.md`、`reports/events.csv`、`reports/data_quality.json`；**v0.2.0 新增共同樣本與逐年測試**：`reports/ROBUSTNESS_REPORT.md`、`reports/ROBUSTNESS.json`、`reports/ROBUSTNESS_predictions.csv`。下載的歷史檔案放在 `data/cache/`，不隨壓縮包附帶。

如果已有 QQQ 的其他 CSV，可用 `python -m alpha_lab run --qqq "D:/path/QQQ.csv" --qqq-interval auto`。

測試流程（**人工合成，非真實績效**）：

```bash
python -m alpha_lab smoke --out reports/smoke
```

## 資料來源

- BTC：<https://github.com/binance/binance-public-data>，BTCUSDT 現貨 5 分鐘 K 線。注意 Binance SPOT 2025-01-01 起時間戳改成微秒；程式會自動辨識。
- QQQ：<https://github.com/lvrusu/QQQ_price_data>，採 `QQQ5m_Ext_J_23_to_Mar_20a_2026.csv`（名稱宣稱 2023–2026/03；**實際需驗證檔案內容**）。即使檔案稱作 5m，盤前部分可能是 30m K 線；已依同日相鄰起點推斷收線時間。QQQ 檔案時間視為美東時區的「K 線起點」。
- 開盤時間：NYSE 交易曆 `exchange_calendars`，處理 DST / 假期。
- 模型：XGBoost，固定超參數且 3 組消融實驗採同算法，避免因模型不同失去比較公平性。

## 防資料洩漏策略

- BTC K 線與 QQQ K 線都轉成 **bar END / 收線時刻**，只允許 `bar_end <= decision_time` 的資料當特徵。
- 09:15 絕對不可看到 09:00–09:30 尚未收線的盤前 30m QQQ K 線。
- 09:15 預測交易到 11:30；09:35 / 10:00 是**後續縮短持有期間**，因此不能把這三個階段的成功率混為同一個事件。
- 固定三段資料：2023–2024 訓練；2025 上半年驗證；2025 下半年以後測試。驗證再切前 60% 校準機率，後 40% 選交易門檻，測試區間完全保留。
- 交易門檻候選固定為 55%、57%、60%、63%、67%；未通過獲利及最小交易次數就**不交易**。
- QQQ 特徵缺失時直接淘汰該 M2/M3 樣本；不靠未來資訊補齊。

## 模擬交易假設

- 每日每階段最多一筆，對該階段測試獨立統計（不同階段不是同一組交易）。
- 以決策時刻最後一根完整 BTC 5m 收盤作為**近似進場價**、11:30 前最後一根完整收盤作為退出價（理想化撮合；非實盤可保證價格）。
- 往返成本預設 0.10%（可 `--cost 0.0015` 調整），另外列出成本假設；**未包含**資金費率、全面滑價模型等。
- 每筆資金投入率 25%；虛擬本金 10,000 USDT；非 0.5% 最大風險保證，因為第一版尚未實作止損。
- 單純預測正確率和扣成本後交易勝率是不同數字。

## 來源與授權

本專案自行撰寫 Python 原始碼；未直接複製第三方程式碼。資料仍受原始資料提供者之政策、授權及可用性約束。研究結果不構成投資建議。
