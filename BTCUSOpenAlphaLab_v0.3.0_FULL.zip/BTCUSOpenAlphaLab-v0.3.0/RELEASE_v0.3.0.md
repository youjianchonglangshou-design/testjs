# BTC US Open Alpha Lab v0.3.0 — GitHub Pages 前向試驗版

## 本次新增
- `docs/index.html`：美股開盤 BTC 方向預測主頁，含三個快照、九組模型訊號、過期提示及結算成績。
- `docs/research.html`：v0.2.0 共同樣本 Walk-Forward 回測對照。
- `live_cloud/engine.py`：無帳戶金鑰的 Binance 現貨 BTC 5m 與 Yahoo Finance QQQ 5m 讀取、固定時間模型推理、JSON 紀錄。
- `live_models/`：九組 XGBoost 模型及校準參數，2025 年底前訓練、2026 第一季校準。
- `.github/workflows/live.yml`：交易日 UTC 13–17 時段每五分鐘排程；計算後提交 `docs/data/*.json` 並部署 GitHub Pages。
- `tests/test_live_cloud.py`：交易日、夏冬令、固定時間、資料不足和凍結回歸測試。

## 風險界線
1. 模型使用截至 2026 年 3 月的 BTC/QQQ 訓練來源，準確率在 v0.2.0 的逐年共同樣本驗證中 **未穩定超越基準**。此版只供今晚前向觀察，**不是交易建議**。
2. 09:15 ET、09:35 ET、10:00 ET 分別觀察 BTC 到 11:30 ET 的漲跌；這三段持有時間不同，與 BTCFLOWPulse 不一定完全可比。
3. GitHub Actions 排程可延誤，因此預測超過決策時點 15 分鐘執行，會標記 `MISSED_WINDOW`，不許以後來取得的資料冒稱即時訊號。
4. Yahoo Finance QQQ 非官方 SIP，可能延誤或缺漏。M2/M3 無 QQQ 即顯示不可用；BTC 不可用則不產生任何機率。
5. GitHub Pages 與 GitHub Actions 需在新倉庫完成啟用；**僅有本地文件不代表已上線**。
6. 使用美股正式開盤日與夏冬令時間；週末、美股休市日不計算新訊號。

## GitHub Pages 部署
1. 在 GitHub 建立 Public Repository：`BTCUSOpenAlphaLab`，不勾選自動建立 README。
2. 將本完整專案上傳 `main`，須含 `docs/`、`.github/workflows/live.yml`、`live_cloud/`、`live_models/`、`requirements-live.txt`。
3. 在 Settings → Pages → Build and deployment，選擇 Source: **GitHub Actions**。
4. 到 Actions 尋找 `BTC US Open — Public Live Snapshot`，手動 Run workflow，驗證 deploy-pages 與 JSON 更新。
5. 預期地址 `https://youjianchonglangshou-design.github.io/BTCUSOpenAlphaLab/`，但只能在實際部署成功後使用。
6. 檢查 `docs/data/latest.json`、`docs/data/YYYY-MM-DD.json` 的 `updated_utc`、`btc_status`、`qqq_status` 和 `phases`。

## 版本交付
- `BTCUSOpenAlphaLab_v0.3.0_FULL.zip`：獨立程式完整包（附模型及前端，無歷史大型資料快取）。
- `BTCUSOpenAlphaLab_v0.3.0_OVERLAY.zip`：直接覆蓋到舊版專案的增量結構（檔案完整相同，無外層資料夾）。
- 遠端電腦原路徑：`Downloads\\BTCUSOpenAlphaLab_v0.1.0_full_project\\BTCUSOpenAlphaLab-v0.1.0`。

## 執行環境
- GitHub Actions: Python 3.11，`requirements-live.txt`。
- 本機測試：`py -3 -m pytest -q`；`py -3 -m live_cloud.engine` 產生當前資料。
- 夜盤主頁每 30 秒重新讀取 Actions 輸出的靜態 JSON，非瀏覽器直接訓練模型。
