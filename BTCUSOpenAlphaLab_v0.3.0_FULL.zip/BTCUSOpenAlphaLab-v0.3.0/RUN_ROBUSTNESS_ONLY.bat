@echo off
cd /d "%~dp0"
echo BTC US Open Alpha Lab v0.2.0 - matched / walk-forward
py -3 -m pytest -q --disable-warnings
if errorlevel 1 goto fail
if not exist reports\events.csv (
 echo Missing original historical events.csv. Run RUN_WINDOWS.bat first.
 goto fail
)
py -3 -m alpha_lab robustness
if errorlevel 1 goto fail
echo.
echo Success. Results saved in reports.
start "" http://127.0.0.1:8000/web/
py -3 -m http.server 8000
exit /b 0
:fail
echo.
echo Validation failed. No missing data was fabricated.
pause
exit /b 1
