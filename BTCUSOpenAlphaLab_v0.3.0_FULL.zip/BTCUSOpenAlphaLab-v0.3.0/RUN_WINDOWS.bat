@echo off
cd /d "%~dp0"
echo BTC US Open Alpha Lab v0.2.0
py -3 -m pip install -r requirements.txt
if errorlevel 1 goto fail
py -3 -m pytest -q
if errorlevel 1 goto fail
py -3 -m alpha_lab download --start 2023-01 --end 2026-03
if errorlevel 1 goto fail
py -3 -m alpha_lab run --start 2023-01 --end 2026-03
if errorlevel 1 goto fail
py -3 -m alpha_lab robustness
if errorlevel 1 goto fail
echo.
echo Historical run complete. Open http://127.0.0.1:8000/web/
start "" http://127.0.0.1:8000/web/
py -3 -m http.server 8000
exit /b 0
:fail
echo.
echo The process stopped. Check network and error above. No fabricated results were produced.
pause
exit /b 1
