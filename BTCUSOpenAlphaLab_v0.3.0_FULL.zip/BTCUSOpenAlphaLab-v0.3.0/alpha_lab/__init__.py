"""BTC US Open Alpha Lab - independent research prototype."""
__version__ = '0.1.0'
