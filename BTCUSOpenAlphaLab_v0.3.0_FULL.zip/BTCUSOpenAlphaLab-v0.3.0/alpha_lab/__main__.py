"""Command-line entry point."""
import argparse
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

from .data import download_data, load_btc, load_qqq, data_quality, QQQ_URL
from .events import build_events
from .model import analyze
from .robustness import analyze_robustness, write_robustness


def _write_report(report, output: Path, events=None, quality=None):
    output.mkdir(parents=True, exist_ok=True)
    if events is not None:
        events.to_csv(output/'events.csv', index=False)
    (output/'latest.json').write_text(json.dumps(report, ensure_ascii=False,indent=2,
                              allow_nan=False),encoding='utf-8')
    if quality is not None:
        (output/'data_quality.json').write_text(json.dumps(quality,ensure_ascii=False,
                              indent=2),encoding='utf-8')
    lines = [f'# BTC US Open Alpha Lab — {report["version"]}',
             '',f'資料模式：**{report["data_mode"]}**',
             f'訓練截至 {report["train_end"]}；驗證截至 {report["validation_end"]}；其後樣本外測試。',
             f'交易成本：每筆往返 {report["roundtrip_cost"]*100:.2f}%；',
             f'模擬初始本金：10,000 USDT；單筆投入資金比率：25%（非停損保證）。','',
             '> 警告：歷史模擬不是即時交易；不含完整委託簿滑價、稅與衍生品資金費率。',
             '> 若是 synthetic，僅代表流程測試，絕不能作為真實歷史成功率。','']
    for name, market in report['markets'].items():
        lines += [f'## {name}',f'事件 {market["event_count"]}；訓練 {market["train_count"]}；驗證 {market["validation_count"]}；測試 {market["test_count"]}', '']
        if 'baseline' not in market:
            lines += [f'無法評分：{market.get("status","unknown")}','']
            continue
        base=market['baseline']
        lines += [f'單純基準：accuracy {base["accuracy"]*100:.2f}%；Brier {base["brier"]:.4f}；測試區間上漲率 {base["test_up_frequency"]*100:.2f}%。','',
                  '| 模型 | 測試數 | 正確率 | Brier | 模擬交易次數 | 淨勝率 | 模擬終值 |',
                  '|---|---:|---:|---:|---:|---:|---:|']
        for model_name,m in market['models'].items():
            if m['status']!='tested':
                lines.append(f'| {model_name} | — | {m["status"]} | — | — | — | — |')
            else:
                p=m['paper'];wins='—' if p['win_rate'] is None else f'{p["win_rate"]*100:.2f}%'
                lines.append(f'| {model_name} | {m["test"]} | {m["scores"]["accuracy"]*100:.2f}% | {m["scores"]["brier"]:.4f} | {p["trades"]} | {wins} | {p["ending_equity"]:,.2f} |')
        lines += ['', '未達預先指定的驗證集交易門檻時，採用不交易，避免硬湊勝率。', '']
    (output/'REPORT.md').write_text('\n'.join(lines),encoding='utf-8')
    print('WROTE',output/'latest.json')
    print('WROTE',output/'REPORT.md')


def _synthetic_events(seed=19):
    # Deliberately artificial: validates serialization + pipeline, not price prediction.
    rng=np.random.default_rng(seed)
    dates=pd.bdate_range('2023-01-03','2026-03-20')
    rows=[]
    for dt in dates:
        one=rng.standard_normal(3)
        btc1,btc4,qqq=one
        for phase in ('pre15','post05','post30'):
            pm=rng.normal(0,0.003) + qqq*0.0015
            prob=1/(1+np.exp(-(0.7*btc1+0.7*qqq)))
            up=int(rng.random() < prob)
            ret=(1 if up else -1) * (0.0015 + rng.random()*0.003)
            rows.append({'session':dt.strftime('%Y-%m-%d'),'phase':phase,
                        'hold_return':ret,'up':up,
                        'btc_ret_12':btc1*0.002,'btc_ret_48':btc4*0.004,
                        'btc_ret_96':rng.normal(0,0.01),
                        'vol_60':abs(rng.normal(0.0009,0.0002)),
                        'qqq_premarket':pm,'qqq_rth':0.0 if phase=='pre15' else rng.normal(0,0.003),
                        'buy_imbalance':rng.normal(0,0.08),
                        'volume_boost':rng.uniform(0.5,2.5),
                        'btc_qqq_divergence':btc4*0.004-pm})
    return pd.DataFrame(rows)


def main(argv=None):
    a=argparse.ArgumentParser(description='BTC US Open Alpha Lab, v0.2.0')
    sub=a.add_subparsers(dest='command',required=True)
    d=sub.add_parser('download',help='Fetch public historical data (requires network)')
    d.add_argument('--start',default='2023-01');d.add_argument('--end',default='2026-03')
    d.add_argument('--qqq-url',default=QQQ_URL)
    r=sub.add_parser('run',help='Actual historical run; refuses missing source data')
    r.add_argument('--start',default='2023-01');r.add_argument('--end',default='2026-03')
    r.add_argument('--qqq',default=None,help='Path to QQQ CSV (default cached QQQ5m_extended.csv)')
    r.add_argument('--qqq-interval',default='auto',help='auto, 1, 5, 30')
    r.add_argument('--train-end',default='2024-12-31')
    r.add_argument('--val-end',default='2025-06-30')
    r.add_argument('--cost',type=float,default=0.001)
    r.add_argument('--out',default='reports')
    rb=sub.add_parser('robustness',help='Matched-day, year-by-year walk-forward study')
    rb.add_argument('--events',default='reports/events.csv')
    rb.add_argument('--out',default='reports')
    rb.add_argument('--cost',type=float,default=0.001)
    e=sub.add_parser('smoke',help='SYNTHETIC ONLY, test pipeline end-to-end')
    e.add_argument('--out',default='reports/smoke')
    args=a.parse_args(argv)
    cache=Path('data/cache')
    if args.command=='download':
        print(json.dumps(download_data(cache,args.start,args.end,args.qqq_url),indent=2))
    elif args.command=='run':
        qpath=Path(args.qqq) if args.qqq else cache/'QQQ5m_extended.csv'
        btc=load_btc(cache,args.start,args.end)
        qqq=load_qqq(qpath,args.qqq_interval)
        q=data_quality(btc,qqq)
        events=build_events(btc,qqq)
        if events.empty: raise ValueError('Zero valid open events; verify data and timezones')
        rep=analyze(events,args.train_end,args.val_end,cost=args.cost,
                    data_mode='historical (external community QQQ source)')
        _write_report(rep,Path(args.out),events,quality=q)
        print('DATA QUALITY',json.dumps(q))
    elif args.command=='robustness':
        path=Path(args.events)
        if not path.is_file():
            raise FileNotFoundError(f'Missing real events file: {path}; run historical study first')
        events=pd.read_csv(path)
        required_provenance={'decision_ny','close_ny','base_close','future_close'}
        if not required_provenance.issubset(events.columns):
            raise ValueError('Missing historical event provenance columns; refusing synthetic/unknown data')
        metadata=Path(args.out)/'latest.json'
        if not metadata.is_file():
            raise FileNotFoundError('Missing historical report metadata latest.json')
        mode=json.loads(metadata.read_text(encoding='utf-8')).get('data_mode','')
        if 'historical' not in str(mode).lower() or 'synthetic' in str(mode).lower():
            raise ValueError('Robustness only accepts verified historical pipeline mode')
        result, predictions=analyze_robustness(events,cost=args.cost)
        write_robustness(result,predictions,Path(args.out))
        print('WROTE',Path(args.out)/'ROBUSTNESS_REPORT.md')
        print('WROTE',Path(args.out)/'ROBUSTNESS.json')
        print('WROTE',Path(args.out)/'ROBUSTNESS_predictions.csv')
    else:
        events=_synthetic_events()
        rep=analyze(events,data_mode='SYNTHETIC_SMOKE_TEST_NOT_REAL_MARKET_DATA')
        _write_report(rep,Path(args.out),events)
        print('SMOKE TEST: generated SYNTHETIC DATA, not historical results!')


if __name__ == '__main__':
    main()
