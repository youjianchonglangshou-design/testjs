"""Public-data ingest. Deliberately fail closed on missing/invalid bars."""
from __future__ import annotations

from datetime import date
from pathlib import Path
from zoneinfo import ZoneInfo
import hashlib
import io
import urllib.request
import zipfile

import numpy as np
import pandas as pd

QQQ_URL = ('https://raw.githubusercontent.com/lvrusu/QQQ_price_data/main/'
           'QQQ5m_Ext_J_23_to_Mar_20a_2026.csv')
BINANCE_BASE = 'https://data.binance.vision/data/spot/monthly/klines/BTCUSDT/5m/'
BTC_COLS = ['open_time','open','high','low','close','volume','close_time',
            'quote_volume','num_trades','taker_buy_base','taker_buy_quote','ignore']
NY = ZoneInfo('America/New_York')


def _download(url: str, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and path.stat().st_size > 0:
        return
    temp = path.with_suffix(path.suffix + '.part')
    req = urllib.request.Request(url, headers={'User-Agent': 'BTCUSOpenAlphaLab/0.1'})
    try:
        with urllib.request.urlopen(req, timeout=75) as r, open(temp, 'wb') as fout:
            while chunk := r.read(1024 * 1024):
                fout.write(chunk)
        if temp.stat().st_size == 0:
            raise ValueError(f'Empty download: {url}')
        temp.replace(path)
    finally:
        temp.unlink(missing_ok=True)


def months_between(start: str, end: str) -> list[str]:
    a = pd.Period(start, freq='M')
    b = pd.Period(end, freq='M')
    if b < a:
        raise ValueError('end month precedes start month')
    return [str(p) for p in pd.period_range(a, b, freq='M')]


def download_data(cache: Path, start='2023-01', end='2026-03', qqq_url=QQQ_URL) -> dict:
    cache.mkdir(parents=True, exist_ok=True)
    if pd.Period(end, 'M') > pd.Period(date.today(), 'M'):
        raise ValueError('Requested months in the future')
    qqq = cache / 'QQQ5m_extended.csv'
    _download(qqq_url, qqq)
    files = []
    for month in months_between(start, end):
        name = f'BTCUSDT-5m-{month}.zip'
        path = cache / name
        _download(BINANCE_BASE + name, path)
        with zipfile.ZipFile(path) as z:
            if z.testzip() is not None:
                raise ValueError(f'Corrupt archive: {path}')
        files.append(str(path))
    return {'btc_months': len(files), 'qqq_file': str(qqq), 'btc_files': files}


def _normalize_epoch(value: pd.Series) -> pd.DatetimeIndex:
    n = pd.to_numeric(value, errors='coerce')
    if n.isna().any():
        raise ValueError('Invalid BTC timestamps; cannot normalize')
    # Binance spot switched from milliseconds to microseconds starting 2025.
    ms = n.astype('int64')
    ms = ms.where(ms.abs() < 100_000_000_000_000, ms // 1000)
    return pd.to_datetime(ms, unit='ms', utc=True)


def load_btc(cache: Path, start='2023-01', end='2026-03') -> pd.DataFrame:
    frames = []
    for month in months_between(start, end):
        path = cache / f'BTCUSDT-5m-{month}.zip'
        if not path.exists():
            raise FileNotFoundError(f'{path} is missing; run download first')
        with zipfile.ZipFile(path) as z:
            if len(z.namelist()) != 1:
                raise ValueError(f'Unexpected zip contents {path}')
            with z.open(z.namelist()[0]) as f:
                frame = pd.read_csv(f, header=None, names=BTC_COLS, low_memory=False)
        frame['open_time'] = pd.to_numeric(frame['open_time'], errors='coerce')
        frame = frame.loc[frame.open_time.notna()].copy()  # allows optional CSV header
        if frame.empty:
            raise ValueError(f'No candles in {path}')
        frame['start_utc'] = _normalize_epoch(frame['open_time'])
        for c in ('open','high','low','close','quote_volume','taker_buy_quote'):
            frame[c] = pd.to_numeric(frame[c], errors='coerce')
        frames.append(frame[['start_utc','open','high','low','close','quote_volume','taker_buy_quote']])
    btc = pd.concat(frames, ignore_index=True)
    btc = btc.sort_values('start_utc').drop_duplicates('start_utc', keep='last')
    btc['end_utc'] = btc['start_utc'] + pd.Timedelta(minutes=5)
    btc = btc.set_index('end_utc').sort_index()
    btc['ret5'] = btc['close'].pct_change(fill_method=None)
    gaps = btc.index.to_series().diff().ne(pd.Timedelta(minutes=5))
    btc.loc[gaps.to_numpy(), 'ret5'] = np.nan
    # Rolling features must not bridge missing data or a missing month.
    segment = gaps.cumsum()
    for n in (12, 48, 96):
        g = btc.groupby(segment, sort=False)
        btc[f'btc_ret_{n}'] = g['close'].pct_change(n, fill_method=None)
    btc['vol_60'] = btc.groupby(segment)['ret5'].transform(lambda x: x.rolling(12, min_periods=12).std())
    buy = btc['taker_buy_quote'].groupby(segment).transform(lambda x: x.rolling(12, min_periods=12).sum())
    total = btc['quote_volume'].groupby(segment).transform(lambda x: x.rolling(12, min_periods=12).sum())
    btc['buy_imbalance'] = (buy / total - 0.5).where(total > 0)
    btc['volume_boost'] = btc['quote_volume'].groupby(segment).transform(
        lambda x: x.rolling(12, min_periods=12).mean() / x.rolling(288, min_periods=288).mean()
    )
    if btc['close'].le(0).any() or btc['close'].isna().any():
        raise ValueError('Bad BTC prices')
    return btc


def load_qqq(path: Path, interval: str='auto') -> pd.DataFrame:
    df = pd.read_csv(path, low_memory=False)
    renamed = {c: c.lower() for c in df.columns}
    df = df.rename(columns=renamed)
    timecol = next((c for c in ('ds', 'datetime', 'timestamp','time') if c in df), None)
    if timecol is None or 'close' not in df:
        raise ValueError('QQQ must have ds (or datetime) and Close')
    dt = pd.to_datetime(df[timecol], errors='coerce')
    if dt.isna().any():
        raise ValueError('Invalid QQQ timestamps')
    if dt.dt.tz is None:
        # Source explicitly uses NY wall clock. DST transition times invalid => discard.
        dt = dt.dt.tz_localize('America/New_York', ambiguous='NaT', nonexistent='NaT')
    else:
        dt = dt.dt.tz_convert('America/New_York')
    df['start_ny'] = dt
    df = df.dropna(subset=['start_ny'])
    for c in ('open','high','low','close'):
        if c not in df:
            raise ValueError(f'Missing QQQ OHLC: {c}')
        df[c] = pd.to_numeric(df[c], errors='coerce')
    df = df.dropna(subset=['open','high','low','close'])
    df = df.sort_values('start_ny').drop_duplicates('start_ny')
    if interval == 'auto':
        # Premarket in some upstream "5m" datasets is actually 30m.
        # Infer the bar duration from the next timestamp within a NY session.
        next_start = df.groupby(df['start_ny'].dt.date)['start_ny'].shift(-1)
        diff = (next_start - df['start_ny']).dt.total_seconds().div(60)
        # End-of-day defaults to five minutes; premarket last bar ends at 09:30.
        diff = diff.where(diff.between(1, 30), 5)
        delta = pd.to_timedelta(diff, unit='minute')
    else:
        delta = pd.Timedelta(minutes=int(interval))
    df['end_ny'] = df['start_ny'] + delta
    df['day'] = df['start_ny'].dt.date
    return df.set_index('end_ny').sort_index()


def data_quality(btc: pd.DataFrame, qqq: pd.DataFrame) -> dict:
    bdiff = btc.index.to_series().diff().dropna()
    qdur = (qqq.index.to_series() - pd.DatetimeIndex(qqq['start_ny'])).dt.total_seconds() / 60
    return {
        'btc_bars': int(len(btc)), 'btc_first_utc': str(btc.index.min()),
        'btc_last_utc': str(btc.index.max()),
        'btc_missing_5m_intervals': int((bdiff > pd.Timedelta(minutes=5)).sum()),
        'qqq_bars': int(len(qqq)), 'qqq_first_ny': str(qqq.index.min()),
        'qqq_last_ny': str(qqq.index.max()),
        'qqq_bar_duration_min': sorted(map(int, set(qdur))),
    }
