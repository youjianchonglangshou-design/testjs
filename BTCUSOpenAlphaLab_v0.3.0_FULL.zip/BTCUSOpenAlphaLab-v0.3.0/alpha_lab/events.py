"""Events aligned to the New York Stock Exchange opening bell.

All feature bars must be closed at or before prediction time.
"""
from __future__ import annotations

import exchange_calendars as xc
import numpy as np
import pandas as pd

BTC_FEATURES = ['btc_ret_12','btc_ret_48','btc_ret_96', 'vol_60',
                'buy_imbalance', 'volume_boost']
PHASES = {'pre15': -15, 'post05': 5, 'post30': 30}


def _btc_at(btc: pd.DataFrame, when: pd.Timestamp, max_lag=6):
    when = when.tz_convert('UTC')
    i = btc.index.searchsorted(when, side='right') - 1
    if i < 0 or (when - btc.index[i]) > pd.Timedelta(minutes=max_lag):
        return None
    return btc.iloc[i]


def _qqq_last(day_bars: pd.DataFrame, decision: pd.Timestamp):
    # day_bars index is completion time in New York, not bar-start time.
    bars = day_bars.loc[day_bars.index <= decision]
    return None if bars.empty else bars.iloc[-1]


def _make_prev_close(qqq: pd.DataFrame, cal) -> dict:
    closes = {}
    for day, frame in qqq.groupby('day', sort=True):
        if not cal.is_session(pd.Timestamp(day)):
            continue
        opening = cal.session_open(pd.Timestamp(day)).tz_convert('America/New_York')
        closing = cal.session_close(pd.Timestamp(day)).tz_convert('America/New_York')
        rth = frame.loc[(frame['start_ny'] >= opening) &
                        (frame.index <= closing) & (frame.index >= opening)]
        if not rth.empty and closing - rth.index[-1] <= pd.Timedelta(minutes=10):
            closes[pd.Timestamp(day)] = float(rth.iloc[-1]['close'])
    return closes


def build_events(btc: pd.DataFrame, qqq: pd.DataFrame, phases=None) -> pd.DataFrame:
    phases = PHASES if phases is None else phases
    cal = xc.get_calendar('XNYS')
    bmin = btc.index.min().tz_convert('America/New_York').date()
    bmax = btc.index.max().tz_convert('America/New_York').date()
    sessions = cal.sessions_in_range(str(bmin), str(bmax))
    day_frames = {k: v for k,v in qqq.groupby('day', sort=True)}
    rthclose = _make_prev_close(qqq, cal)
    rows = []
    prev_day = None
    for day in sessions:
        daykey = pd.Timestamp(day.date())
        opening = cal.session_open(day).tz_convert('America/New_York')
        end = opening + pd.Timedelta(minutes=120)
        future = _btc_at(btc, end)
        open_btc = _btc_at(btc, opening)
        if future is None or open_btc is None:
            prev_day = daykey
            continue
        bars = day_frames.get(day.date())
        prev_close = rthclose.get(prev_day) if prev_day is not None else None
        prev_day = daykey
        for phase, offset in phases.items():
            when = opening + pd.Timedelta(minutes=offset)
            b = _btc_at(btc, when)
            if b is None:
                continue
            # Volatility / lagged features may be NaN, but no future bars are used.
            row = {'session': str(day.date()), 'phase': phase,
                   'decision_ny': when.isoformat(), 'close_ny': end.isoformat(),
                   'minutes_to_end': 120 - offset,
                   'base_close': float(b['close']), 'future_close': float(future['close'])}
            row['hold_return'] = row['future_close']/row['base_close'] - 1
            if row['hold_return'] == 0:
                continue
            row['up'] = int(row['hold_return'] > 0)
            for c in BTC_FEATURES:
                row[c] = float(b[c]) if pd.notna(b[c]) else np.nan
            row['qqq_premarket'] = np.nan
            row['qqq_rth'] = 0.0 if offset <= 0 else np.nan
            if bars is not None:
                pm = bars.loc[(bars['start_ny'].dt.hour >= 4) &
                              (bars['start_ny'] < opening) &
                              (bars.index <= min(when, opening))]
                if prev_close and not pm.empty:
                    # In pre15, the 09:00–09:30 premarket bar has not closed!
                    last = pm.iloc[-1]
                    if (when - pm.index[-1]) <= pd.Timedelta(minutes=60):
                        row['qqq_premarket'] = float(last['close'])/prev_close - 1
                if offset > 0:
                    rth = bars.loc[(bars['start_ny'] >= opening) &
                                   (bars.index <= when)]
                    if not rth.empty and rth.iloc[0]['start_ny'] == opening:
                        row['qqq_rth'] = float(rth.iloc[-1]['close'])/float(rth.iloc[0]['open']) - 1
            row['btc_qqq_divergence'] = (
                row['btc_ret_48'] - row['qqq_premarket']
                if pd.notna(row['qqq_premarket']) and pd.notna(row['btc_ret_48'])
                else np.nan
            )
            rows.append(row)
    return pd.DataFrame.from_records(rows)
