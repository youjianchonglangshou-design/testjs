"""Fixed-parameter controlled ablation, chronological holdout, paper simulator."""
from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score, brier_score_loss, log_loss
from sklearn.linear_model import LogisticRegression
from xgboost import XGBClassifier

FEATURE_SETS = {
    'M1_BTC': ['btc_ret_12','btc_ret_48','btc_ret_96','vol_60'],
    'M2_BTC_QQQ': ['btc_ret_12','btc_ret_48','btc_ret_96','vol_60',
                   'qqq_premarket','qqq_rth'],
    'M3_BTC_QQQ_TAPE': ['btc_ret_12','btc_ret_48','btc_ret_96','vol_60',
                        'qqq_premarket','qqq_rth','buy_imbalance',
                        'volume_boost','btc_qqq_divergence'],
}


def _probs(model, d, cols):
    return np.asarray(model.predict_proba(d[cols])[:, 1], dtype=float)


def _new_model():
    return XGBClassifier(n_estimators=140, max_depth=2, learning_rate=0.035,
                         subsample=0.9, colsample_bytree=0.9,
                         reg_lambda=8.0, random_state=19,
                         objective='binary:logistic', eval_metric='logloss',
                         n_jobs=2)


def _calibrator(cal_p: np.ndarray, labels: np.ndarray):
    if len(cal_p) < 20 or len(np.unique(labels)) != 2:
        return None
    # Independent chronological calibration subset; threshold selection uses later rows.
    tiny = np.clip(cal_p, 1e-5, 1 - 1e-5)
    scores = np.log(tiny/(1-tiny)).reshape(-1,1)
    lr = LogisticRegression(C=2.0, random_state=19)
    lr.fit(scores, labels)
    return lr


def _calibrate(cal, p):
    if cal is None:
        return p
    p = np.clip(p, 1e-5, 1-1e-5)
    return cal.predict_proba(np.log(p/(1-p)).reshape(-1,1))[:,1]


def _signals(p: np.ndarray, threshold):
    if threshold is None:
        return np.zeros(len(p), dtype=int)
    return np.where(p >= threshold, 1, np.where(p <= 1-threshold, -1, 0))


def _choose_threshold(p, r, fee, min_trades=12):
    choices = []
    for th in (0.55, 0.57, 0.60, 0.63, 0.67):
        s = _signals(p, th)
        ix = s != 0
        if ix.sum() < min_trades:
            continue
        net = s[ix]*r[ix] - fee
        wins = (net > 0).mean()
        # Avoid activating a strategy for a tiny or losing calibration-validation advantage.
        if wins > 0.52 and net.mean() > 0:
            choices.append((float(net.mean()), th))
    return max(choices)[1] if choices else None


def _trade_stats(df, p, threshold, roundtrip_cost=0.001, account=10000, exposure=0.25):
    s = _signals(p, threshold)
    selected = df.loc[s != 0].copy()
    selected['direction'] = s[s != 0]
    selected['probability_up'] = p[s != 0]
    selected['net_return'] = selected['direction'] * selected['hold_return'] - roundtrip_cost
    equity = account * (1 + exposure*selected['net_return']).cumprod()
    if equity.empty:
        return {'trades':0, 'win_rate':None, 'avg_net_return':None,
                'profit_factor':None,'starting_equity':account,
                'ending_equity':account,'max_drawdown':None}, []
    positive = selected['net_return'].clip(lower=0).sum()
    negative = -selected['net_return'].clip(upper=0).sum()
    tops = pd.concat([pd.Series([account]), equity], ignore_index=True).cummax().iloc[1:].to_numpy()
    drawdown = equity.to_numpy()/tops-1
    trades = selected[['session','phase','direction','probability_up',
                       'hold_return','net_return']].copy()
    trades['equity'] = equity.to_numpy()
    trades = trades.replace({np.nan:None})
    stats = {'trades': int(len(selected)),
             'win_rate':float((selected.net_return > 0).mean()),
             'avg_net_return':float(selected.net_return.mean()),
             'profit_factor':float(positive/negative) if negative > 0 else None,
             'starting_equity':float(account), 'ending_equity':float(equity.iloc[-1]),
             'max_drawdown':float(np.min(drawdown))}
    return stats, trades.to_dict(orient='records')


def _score(y, p):
    return {'accuracy':float(accuracy_score(y, p>=0.5)),
            'brier':float(brier_score_loss(y, p)),
            'log_loss':float(log_loss(y, p, labels=[0,1]))}


def analyze(events:pd.DataFrame, train_end='2024-12-31',
            val_end='2025-06-30', cost=0.001, min_rows=100,
            min_val=40, min_test=20, data_mode='historical') -> dict:
    if events.empty:
        raise ValueError('No event rows, check BTC / QQQ coverage')
    if not train_end < val_end:
        raise ValueError('train_end must precede val_end')
    output = {'version':'0.2.0','data_mode':data_mode,
              'train_end':train_end,'validation_end':val_end,
              'roundtrip_cost':cost,'initial_paper_equity':10000,
              'position_exposure':0.25,'markets':{},
              'events_total':len(events),
              'source_notice':'QQQ community dataset is not official SIP; independently validate.'}
    for phase, phase_data in events.groupby('phase', sort=True):
        phase_data = phase_data.sort_values('session').copy()
        train = phase_data[phase_data.session <= train_end]
        val = phase_data[(phase_data.session > train_end) & (phase_data.session <= val_end)]
        test = phase_data[phase_data.session > val_end]
        phase_out = {'event_count':len(phase_data),
                     'train_count':len(train),'validation_count':len(val),
                     'test_count':len(test),'models':{}}
        output['markets'][phase] = phase_out
        if min(len(train),len(val),len(test)) < min(min_rows,min_val,min_test):
            # More precise validation per stage below.
            if len(train) < min_rows or len(val) < min_val or len(test) < min_test:
                phase_out['status']='insufficient split samples'
                continue
        prior = float(train.up.mean())
        phase_out['baseline'] = {**_score(test.up.to_numpy(), np.full(len(test),prior)),
                                 'train_up_probability':prior,
                                 'test_up_frequency':float(test.up.mean())}
        for model_name, cols in FEATURE_SETS.items():
            # No QQQ backfilling: if data is missing the dated session is excluded.
            data = [d.dropna(subset=cols).copy() for d in (train,val,test)]
            tr,va,te = data
            if len(tr) < min_rows or len(va) < min_val or len(te) < min_test:
                phase_out['models'][model_name] = {'status':'insufficient complete feature rows',
                    'train':len(tr),'validation':len(va),'test':len(te)}
                continue
            if tr.up.nunique() != 2:
                phase_out['models'][model_name] = {'status':'single-class training split'}
                continue
            model = _new_model()
            model.fit(tr[cols],tr.up)
            # First 60% of val: probability calibration; remaining 40%: trade threshold selection.
            pivot = int(len(va)*0.6)
            cal = _calibrator(_probs(model,va.iloc[:pivot],cols), va.up.iloc[:pivot].to_numpy())
            selection = va.iloc[pivot:]
            p_selection = _calibrate(cal,_probs(model,selection,cols))
            threshold = _choose_threshold(p_selection, selection.hold_return.to_numpy(), cost)
            prob = _calibrate(cal,_probs(model,te,cols))
            paper, trades = _trade_stats(te,prob,threshold,cost)
            phase_out['models'][model_name] = {'status':'tested',
                'train':len(tr),'validation':len(va),'test':len(te),
                'features':cols,'calibrated':cal is not None,
                'threshold':threshold,'scores':_score(te.up.to_numpy(),prob),
                'test_up_frequency':float(te.up.mean()),
                'paper':paper,'trades':trades}
    return output
