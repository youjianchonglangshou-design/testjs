"""Matched-day walk-forward comparison. Every model sees identical train/val/test dates."""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import binomtest
from sklearn.metrics import accuracy_score, brier_score_loss, log_loss

from .model import (
    FEATURE_SETS, _calibrator, _calibrate, _choose_threshold,
    _new_model, _probs, _score, _signals,
)

FOLDS = (
    dict(name="2024_H2", train_end="2023-12-31",
         val_start="2024-01-01", val_end="2024-06-30",
         test_start="2024-07-01", test_end="2024-12-31"),
    dict(name="2025", train_end="2024-06-30",
         val_start="2024-07-01", val_end="2024-12-31",
         test_start="2025-01-01", test_end="2025-12-31"),
    dict(name="2026_Q1", train_end="2025-06-30",
         val_start="2025-07-01", val_end="2025-12-31",
         test_start="2026-01-01", test_end="2026-03-31"),
)
ALL_FEATURES = sorted({c for cols in FEATURE_SETS.values() for c in cols})
MODEL_NAMES = ["M0_BASELINE", *FEATURE_SETS.keys()]


def matched_sessions(events: pd.DataFrame, phase: str) -> pd.DataFrame:
    """No QQQ missing-value interpolation; same dates for M0, M1, M2, M3."""
    required = set(ALL_FEATURES) | {"session", "phase", "up", "hold_return"}
    missing = required - set(events.columns)
    if missing:
        raise ValueError(f"Missing event columns: {sorted(missing)}")
    df = events.loc[events["phase"] == phase].copy()
    df[ALL_FEATURES + ["up", "hold_return"]] = df[
        ALL_FEATURES + ["up", "hold_return"]
    ].apply(pd.to_numeric, errors="coerce")
    df = df.replace([np.inf, -np.inf], np.nan)
    df = df.dropna(subset=ALL_FEATURES + ["up", "hold_return"])
    df = df.sort_values("session").reset_index(drop=True)
    if df.session.duplicated().any():
        raise ValueError(f"Duplicate NYSE session in {phase}")
    return df


def _partition(df: pd.DataFrame, spec: dict):
    train = df[df.session <= spec["train_end"]].copy()
    val = df[(df.session >= spec["val_start"]) &
             (df.session <= spec["val_end"])].copy()
    test = df[(df.session >= spec["test_start"]) &
              (df.session <= spec["test_end"])].copy()
    if any(a.session.isin(b.session).any()
           for a, b in ((train, val), (train, test), (val, test))):
        raise AssertionError("Fold train, validation and test overlap")
    return train, val, test


def _trade_summary(frame: pd.DataFrame, signal_col: str, cost: float):
    selected = frame.loc[frame[signal_col].astype(int) != 0]
    sig = selected[signal_col].astype(int).to_numpy()
    returns = sig * selected["hold_return"].to_numpy(dtype=float) - cost
    equity = 10000 * np.cumprod(1 + 0.25 * returns)
    tops = np.maximum.accumulate(np.r_[10000.0, equity])
    gains = np.maximum(returns, 0).sum()
    losses = -np.minimum(returns, 0).sum()
    return {
        "trades": int(len(returns)),
        "net_win_rate": float((returns > 0).mean()) if len(returns) else None,
        "average_net_trade_return": float(returns.mean()) if len(returns) else None,
        "ending_equity": float(equity[-1]) if len(equity) else 10000.0,
        "max_drawdown": float((np.r_[10000.0, equity] / tops - 1).min()) if len(equity) else 0.0,
        "profit_factor": float(gains / losses) if losses > 0 else None,
    }


def _paired_comparison(frame: pd.DataFrame, candidate: str, reference: str,
                       seed: int = 19):
    """Paired uncertainty across identically dated unseen events."""
    y = frame["up"].to_numpy(dtype=int)
    pc = frame[f"prob_{candidate}"].to_numpy(dtype=float)
    pr = frame[f"prob_{reference}"].to_numpy(dtype=float)
    c = (pc >= .5) == y
    r = (pr >= .5) == y
    difference = c.astype(float) - r.astype(float)
    brier_advantage = (pr - y) ** 2 - (pc - y) ** 2
    n = len(y)
    if not n:
        return None
    rng = np.random.default_rng(seed)
    idx = rng.integers(0, n, size=(2000, n))
    ci_accuracy = np.quantile(difference[idx].mean(axis=1), [.025, .975])
    ci_brier = np.quantile(brier_advantage[idx].mean(axis=1), [.025, .975])
    winner = int((c & ~r).sum())
    loser = int((~c & r).sum())
    discordant = winner + loser
    return {
        "common_test_events": n,
        "accuracy_advantage_pp": float(100 * difference.mean()),
        "accuracy_95pct_bootstrap_CI_pp": [float(100 * x) for x in ci_accuracy],
        "brier_advantage_vs_reference": float(brier_advantage.mean()),
        "brier_95pct_bootstrap_CI": [float(x) for x in ci_brier],
        "candidate_only_correct": winner,
        "reference_only_correct": loser,
        "mcnemar_exact_p": float(binomtest(winner, discordant, .5).pvalue)
            if discordant else 1.0,
    }


def analyze_robustness(events: pd.DataFrame, cost=0.001,
                       min_train=100, min_val=40, min_test=20):
    if not 0 <= cost < 1:
        raise ValueError("Invalid roundtrip cost")
    report = {
        "version": "0.2.0",
        "research_design": "matched complete-case sessions; expanding walk-forward; calibration/threshold on validation only",
        "cost_roundtrip": cost,
        "data_mode": "historical external BTC/QQQ data (QQQ community feed; not independently SIP verified)",
        "fold_specifications": list(FOLDS),
        "phases": {},
    }
    predictions = []
    for phase in sorted(events.phase.unique()):
        matched = matched_sessions(events, phase)
        total = int((events.phase == phase).sum())
        phase_obj = {
            "original_events": total,
            "common_complete_events": int(len(matched)),
            "discarded_due_to_incomplete_features": total - len(matched),
            "folds": {},
        }
        report["phases"][phase] = phase_obj
        for spec in FOLDS:
            tr, va, te = _partition(matched, spec)
            key = spec["name"]
            detail = {
                "train_n": len(tr), "val_n": len(va),
                "test_n": len(te), "models": {},
            }
            phase_obj["folds"][key] = detail
            if len(tr) < min_train or len(va) < min_val or len(te) < min_test:
                detail["status"] = "insufficient matched samples"
                continue
            if tr.up.nunique() != 2:
                detail["status"] = "single-class training"
                continue
            details = te[["session", "phase", "up", "hold_return"]].copy()
            details["fold"] = key
            y = te.up.to_numpy(dtype=int)
            prior = float(tr.up.mean())
            base_p = np.full(len(te), prior, dtype=float)
            details["prob_M0_BASELINE"] = base_p
            details["signal_M0_BASELINE"] = np.zeros(len(te), dtype=int)
            detail["models"]["M0_BASELINE"] = {
                **_score(y, base_p),
                "training_up_frequency": prior, "threshold": None,
            }
            for model_name, columns in FEATURE_SETS.items():
                model = _new_model()
                model.fit(tr[columns], tr.up.to_numpy(dtype=int))
                pivot = int(len(va) * .6)
                calibration = _calibrator(
                    _probs(model, va.iloc[:pivot], columns),
                    va.iloc[:pivot].up.to_numpy(dtype=int))
                p_select = _calibrate(
                    calibration, _probs(model, va.iloc[pivot:], columns))
                threshold = _choose_threshold(
                    p_select, va.iloc[pivot:].hold_return.to_numpy(dtype=float),
                    cost)
                p_test = _calibrate(calibration, _probs(model, te, columns))
                signal = _signals(p_test, threshold)
                details[f"prob_{model_name}"] = p_test
                details[f"signal_{model_name}"] = signal
                detail["models"][model_name] = {
                    **_score(y, p_test),
                    "threshold": threshold,
                    "calibration_fitted": calibration is not None,
                    "validation_selection_n": len(va) - pivot,
                }
            predictions.append(details)
            detail["status"] = "evaluated"
        frames = [f for f in predictions if str(f.phase.iloc[0]) == phase]
        if not frames:
            phase_obj["status"] = "no valid out-of-sample folds"
            continue
        all_oos = pd.concat(frames, ignore_index=True).sort_values("session")
        phase_obj["aggregated_test_n"] = len(all_oos)
        phase_obj["common_sample_models"] = {}
        for name in MODEL_NAMES:
            probabilities = all_oos[f"prob_{name}"].to_numpy(dtype=float)
            metrics = _score(all_oos.up.to_numpy(dtype=int), probabilities)
            metrics["trade_simulation"] = _trade_summary(
                all_oos, f"signal_{name}", cost)
            phase_obj["common_sample_models"][name] = metrics
        phase_obj["paired_model_tests"] = {
            f"{name}_vs_M1": _paired_comparison(all_oos, name, "M1_BTC")
            for name in ("M2_BTC_QQQ", "M3_BTC_QQQ_TAPE")
        }
        phase_obj["paired_model_tests"]["M2_vs_M0"] = _paired_comparison(
            all_oos, "M2_BTC_QQQ", "M0_BASELINE")
    if predictions:
        all_predictions = pd.concat(predictions, ignore_index=True)
        if all_predictions.duplicated(subset=["phase", "session"]).any():
            raise AssertionError("One phase has repeated out-of-sample sessions")
    else:
        all_predictions = pd.DataFrame()
    return report, all_predictions


def _percent(v):
    return "—" if v is None else f"{100*v:.2f}%"


def write_robustness(report, predictions, out: Path):
    out.mkdir(parents=True, exist_ok=True)
    (out / "ROBUSTNESS.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False),
        encoding="utf-8")
    predictions.to_csv(out / "ROBUSTNESS_predictions.csv", index=False)
    lines = [
        "# BTC US Open Alpha Lab v0.2.0 — 共同樣本 / 逐年 Walk-Forward 驗證",
        "",
        "**注意：僅為歷史研究。QQQ 社群資料未獨立對照官方 SIP；不是即時訊號，也不構成盈利保證。**",
        "",
        "方法：M0、M1、M2、M3 全部強制使用同一批完整交易日，每輪依時間順序分訓練、驗證、測試；",
        "驗證前 60% 只做機率校準，後 40% 選定交易門檻；測試資料完全不參與選參。",
        "逐年折線窗口為 2024 H2、2025、2026 Q1。樣本可能因資料缺漏被排除。",
        f"模擬成本：每次往返 {report['cost_roundtrip']*100:.2f}%；每筆投入當時本金 25%，不含槓桿、資金費率與真實滑價。",
        "",
    ]
    labels = {
        "M0_BASELINE": "M0 先驗基準",
        "M1_BTC": "M1 BTC",
        "M2_BTC_QQQ": "M2 BTC+QQQ",
        "M3_BTC_QQQ_TAPE": "M3 BTC+QQQ+Tape",
    }
    for phase, obj in report["phases"].items():
        lines += [f"## {phase}",
                  f"原始 {obj['original_events']} 筆；共同完整樣本 {obj['common_complete_events']} 筆；排除 {obj['discarded_due_to_incomplete_features']} 筆。",
                  "", "| 測試期 | 訓練筆數 | 驗證筆數 | 測試筆數 | M0 | M1 | M2 | M3 |",
                  "|---|---:|---:|---:|---:|---:|---:|---:|"]
        for key, f in obj["folds"].items():
            m = f["models"]
            entries = [_percent(m.get(name, {}).get("accuracy")) for name in MODEL_NAMES]
            lines.append(f"| {key} | {f['train_n']} | {f['val_n']} | {f['test_n']} | " + " | ".join(entries) + " |")
        lines += ["", "### 合併樣本外績效（2024 H2–2026 Q1）",
                  "| 模型 | 正確率 | Brier（越低越好） | 模擬交易 | 模擬淨勝率 | 模擬終值（USDT） |",
                  "|---|---:|---:|---:|---:|---:|"]
        for name in MODEL_NAMES:
            if name not in obj.get("common_sample_models", {}):
                continue
            m = obj["common_sample_models"][name]
            t = m["trade_simulation"]
            lines.append(f"| {labels[name]} | {_percent(m['accuracy'])} | {m['brier']:.4f} | {t['trades']} | {_percent(t['net_win_rate'])} | {t['ending_equity']:,.2f} |")
        lines += ["", "### 配對差異及不確定性",
                  "正值代表候選模型比比較對象更好；95% CI 為以交易日重抽樣的近似區間；",
                  "McNemar p 值僅針對相同日期的分類正確率，不代表扣成本後的獲利證據。",
                  "| 比較 | 準確率差距（百分點） | 95% CI（百分點） | Brier 改善 | McNemar p |",
                  "|---|---:|---|---:|---:|"]
        for title, p in obj.get("paired_model_tests", {}).items():
            if p is None:
                continue
            lo, hi = p["accuracy_95pct_bootstrap_CI_pp"]
            lines.append(f"| {title} | {p['accuracy_advantage_pp']:+.2f} | [{lo:+.2f}, {hi:+.2f}] | {p['brier_advantage_vs_reference']:+.4f} | {p['mcnemar_exact_p']:.4f} |")
        lines += ["", "### 解讀限制",
                  "- 模型機率接近 50% 時，不能以稍高的正確率直接推論有交易價值。",
                  "- 多模型、多時點測試會增加偶然勝出的風險；探索結果需再以未來資料前向驗證。",
                  "- 交易策略未設滑價敏感度測試，不可當成實盤獲利預測。",
                  ""]
    (out / "ROBUSTNESS_REPORT.md").write_text("\n".join(lines), encoding="utf-8")
    return out
