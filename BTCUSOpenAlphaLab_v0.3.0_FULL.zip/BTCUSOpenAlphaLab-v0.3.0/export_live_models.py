"""Export portable, phase-specific XGBoost models for nightly public-data inference.
Model fitting uses only historical rows earlier than 2026-01; calibration holds out 2026 Q1.
"""
from pathlib import Path
from datetime import datetime,timezone
import json

import numpy as np
import pandas as pd
from alpha_lab.model import FEATURE_SETS,_new_model,_probs,_calibrator

ROOT=Path(__file__).resolve().parent
SOURCE=ROOT/'reports/events.csv'
DEST=ROOT/'live_models'
DEST.mkdir(exist_ok=True)
df=pd.read_csv(SOURCE)
if not {'decision_ny','close_ny','base_close','future_close'}.issubset(df.columns):
    raise ValueError('Training is prohibited on unverified synthetic events')
meta=json.loads((ROOT/'reports/latest.json').read_text(encoding='utf-8'))
if 'historical' not in meta.get('data_mode',''):
    raise ValueError('Invalid dataset provenance')
metadata={'version':'0.3.0','model_family':'XGBoost',
   'label':'BTC close at NYSE open +120m versus close at each decision time',
   'train_end':'2025-12-31','calibration_start':'2026-01-01',
   'source_event_limit':str(df.session.max()), 'generated_utc':datetime.now(timezone.utc).isoformat(),
   'phase_offsets_et_minutes':{'pre15':-15,'post05':5,'post30':30},
   'models':{}}
for phase in ['pre15','post05','post30']:
    metadata['models'][phase]={}
    subset=df.loc[df.phase==phase].copy()
    for name,cols in FEATURE_SETS.items():
        rows=subset.dropna(subset=cols).copy()
        train=rows.loc[rows.session<='2025-12-31']
        holdout=rows.loc[(rows.session>='2026-01-01')&(rows.session<='2026-03-31')]
        if len(train)<100 or len(holdout)<25 or train.up.nunique()!=2 or holdout.up.nunique()!=2:
            raise ValueError(f'Not enough real rows for {phase}/{name}')
        model=_new_model()
        model.fit(train[cols],train.up)
        raw=_probs(model,holdout,cols)
        calibration=_calibrator(raw,holdout.up.to_numpy(dtype=int))
        outfile=f'{phase}_{name}.json'
        model.get_booster().save_model(str(DEST/outfile))
        meta_model={'columns':cols,'filename':outfile,'n_train':len(train),
            'n_calibration':len(holdout),'probability_calibration':'platt_logit' if calibration else 'none',
            'calibration_coefficient':float(calibration.coef_[0,0]) if calibration else 1.0,
            'calibration_intercept':float(calibration.intercept_[0]) if calibration else 0.0,
            'calibration_up_rate':float(holdout.up.mean()),
            'train_up_rate':float(train.up.mean())}
        metadata['models'][phase][name]=meta_model
        print(phase,name,len(train),len(holdout),outfile)
(DEST/'manifest.json').write_text(json.dumps(metadata,indent=2,ensure_ascii=False),encoding='utf-8')
print('MANIFEST',DEST/'manifest.json')
