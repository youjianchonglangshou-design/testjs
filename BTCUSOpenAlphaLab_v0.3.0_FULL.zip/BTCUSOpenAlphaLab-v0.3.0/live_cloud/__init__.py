"""Cloud-facing live prediction module; public data, no account keys."""
