"""Live 5-minute snapshots; public Binance & Yahoo data; no broker keys."""
from __future__ import annotations
import argparse,json,math
from datetime import datetime,timedelta,timezone
from pathlib import Path
from zoneinfo import ZoneInfo
import exchange_calendars as xc
import numpy as np,pandas as pd,requests,xgboost as xgb
ROOT=Path(__file__).resolve().parents[1]
NY=ZoneInfo('America/New_York')
PHASES={'pre15':-15,'post05':5,'post30':30}

def fetch(url):
    r=requests.get(url,timeout=20,headers={'User-Agent':'Mozilla/5.0','Accept':'application/json'})
    r.raise_for_status()
    return r.json()

def btc_bars():
    raw=fetch('https://data-api.binance.vision/api/v3/klines?symbol=BTCUSDT&interval=5m&limit=1000')
    if len(raw)<300: raise ValueError('BTC bars insufficient')
    out=pd.DataFrame(raw)
    idx=pd.to_datetime(pd.to_numeric(out[0]),unit='ms',utc=True)+pd.Timedelta(minutes=5)
    frame=pd.DataFrame({'close':pd.to_numeric(out[4]).to_numpy(),'quote':pd.to_numeric(out[7]).to_numpy(),
        'buy':pd.to_numeric(out[10]).to_numpy()},index=pd.DatetimeIndex(idx))
    if frame.index.duplicated().any():raise ValueError('duplicate BTC bars')
    return frame.sort_index()

def qqq_bars():
    raw=fetch('https://query1.finance.yahoo.com/v8/finance/chart/QQQ?interval=5m&range=5d&includePrePost=true')
    result=raw['chart']['result'][0]
    q=result['indicators']['quote'][0]
    frame=pd.DataFrame({'start':pd.to_datetime(result['timestamp'],unit='s',utc=True).tz_convert(NY),
       'open':q['open'],'close':q['close']}).dropna()
    frame['day']=frame.start.dt.date
    frame['end']=frame.start+pd.Timedelta(minutes=5)
    return frame.set_index('end').sort_index()

def features_btc(frame, decision):
    target=pd.Timestamp(decision)
    past=frame.loc[frame.index<=target]
    if len(past)<289 or target-past.index[-1]>pd.Timedelta(minutes=10):
        raise ValueError('BTC last closed 5M candle not available')
    bars=past.iloc[-289:]
    if not bars.index.to_series().diff().iloc[1:].eq(pd.Timedelta(minutes=5)).all():
        raise ValueError('BTC gaps in rolling window')
    c=bars.close;v=bars.quote
    values={'btc_ret_12':float(c.iloc[-1]/c.iloc[-13]-1),
       'btc_ret_48':float(c.iloc[-1]/c.iloc[-49]-1),
       'btc_ret_96':float(c.iloc[-1]/c.iloc[-97]-1),
       'vol_60':float(c.pct_change(fill_method=None).iloc[-12:].std()),
       'buy_imbalance':float(bars.buy.iloc[-12:].sum()/v.iloc[-12:].sum()-0.5),
       'volume_boost':float(v.iloc[-12:].mean()/v.iloc[-288:].mean())}
    if any(not np.isfinite(x) for x in values.values()):raise ValueError('Invalid BTC features')
    return values,float(c.iloc[-1]),str(past.index[-1])

def features_qqq(df,day,decision,offset):
    opening=pd.Timestamp(datetime.combine(day,datetime.min.time()),tz=NY)+pd.Timedelta(hours=9,minutes=30)
    prior=df[(df.day<day)&(df.start.dt.hour==15)&(df.start.dt.minute>=40)&(df.start.dt.minute<=55)]
    if prior.empty:raise ValueError('QQQ prior session close missing')
    prev_date=prior.day.max()
    if (day-prev_date).days>5:raise ValueError('QQQ last session stale')
    prev=float(prior[prior.day==prev_date].iloc[-1].close)
    same=df[df.day==day]
    pm=same[(same.start>=opening-pd.Timedelta(hours=5,minutes=30))&
            (same.start<opening)&(same.index<=pd.Timestamp(decision))]
    if pm.empty or pd.Timestamp(decision)-pm.index[-1]>pd.Timedelta(minutes=60):
        raise ValueError('QQQ premarket stale or missing')
    premkt=float(pm.iloc[-1].close)/prev-1
    rth=0.0
    if offset>0:
        r=same[(same.start>=opening)&(same.index<=pd.Timestamp(decision))]
        if r.empty or r.iloc[0].start!=opening or pd.Timestamp(decision)-r.index[-1]>pd.Timedelta(minutes=10):
            raise ValueError('QQQ live RTH missing')
        rth=float(r.iloc[-1].close)/float(r.iloc[0].open)-1
    return {'qqq_premarket':premkt,'qqq_rth':rth}

def classify(phase,f):
    manifest=json.loads((ROOT/'live_models/manifest.json').read_text(encoding='utf-8'))
    scores={}
    for name,m in manifest['models'][phase].items():
        cols=m['columns']
        missing=[k for k in cols if k not in f]
        if missing:
            scores[name]={'status':'unavailable','missing_features':missing}
            continue
        model=xgb.Booster()
        model.load_model(str(ROOT/'live_models'/m['filename']))
        raw=float(model.predict(xgb.DMatrix(np.array([[f[x] for x in cols]]),feature_names=cols))[0])
        raw=min(max(raw,1e-6),1-1e-6)
        z=m['calibration_coefficient']*math.log(raw/(1-raw))+m['calibration_intercept']
        p=1/(1+math.exp(-max(-100,min(100,z))))
        scores[name]={'status':'experimental','prob_up':round(p,6),'prob_down':round(1-p,6),
                      'signal':'LONG' if p>=.55 else ('SHORT' if p<=.45 else 'WAIT')}
    return scores

def session_at(now):
    now_ny=now.astimezone(NY)
    date=pd.Timestamp(now_ny.date())
    cal=xc.get_calendar('XNYS')
    if not cal.is_session(date):return None
    start=cal.session_open(date).to_pydatetime().astimezone(NY)
    end=cal.session_close(date).to_pydatetime().astimezone(NY)
    if end-start<timedelta(hours=2):return None
    return date.date(),start,start+timedelta(minutes=120)

def write_json(path,obj):
    path.parent.mkdir(parents=True,exist_ok=True)
    temp=path.with_suffix('.partial')
    temp.write_text(json.dumps(obj,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
    temp.replace(path)

def run(now=None,output=None):
    now=(now or datetime.now(timezone.utc)).astimezone(timezone.utc)
    output=output or ROOT/'docs/data'
    session=session_at(now)
    if session is None:
        print('NYSE CLOSED',now.isoformat());return None
    day,start,target=session
    date=day.isoformat()
    saved=output/f'{date}.json'
    record=json.loads(saved.read_text(encoding='utf-8')) if saved.exists() else {
       'version':'0.3.0','session':date,'open_ny':start.isoformat(),
       'target_ny':target.isoformat(),'train_end':'2025-12-31',
       'market_data':'Binance spot BTCUSDT; Yahoo chart QQQ unofficial',
       'phases':{}}
    record['updated_utc']=now.isoformat()
    record['session_status']='PREOPEN' if now<start else ('OPEN' if now<target else 'SETTLED')
    needed=[(phase,offset,start+timedelta(minutes=offset)) for phase,offset in PHASES.items()
            if now>=start+timedelta(minutes=offset)]
    btc=None
    try:
        btc=btc_bars()
        record['btc_status']='OK'
    except Exception as e:
        record['btc_status']='ERROR '+str(e)[:130]
    qqq=None
    try:
        qqq=qqq_bars()
        record['qqq_status']='OK'
    except Exception as e:
        record['qqq_status']='ERROR '+str(e)[:130]
    if btc is not None:
        closed=btc[btc.index<=pd.Timestamp(now)]
        if not closed.empty:
            record['btc_latest_closed_price']=float(closed.iloc[-1].close)
            record['btc_latest_closed_utc']=closed.index[-1].isoformat()
        for phase,offset,dec in needed:
            if record['phases'].get(phase,{}).get('status') in ('SCORED','MISSED_WINDOW'):
                continue # Never rewrite a locked forecast, and never backfill missed forward signals.
            lag=(now-dec).total_seconds()
            if lag>15*60:
                record['phases'][phase]={'status':'MISSED_WINDOW',
                    'decision_ny':dec.isoformat(),
                    'reason':'GitHub job arrived more than 15m after the decision; cannot claim live prediction'}
                continue
            try:
                f,entry,candle=features_btc(btc,dec)
                qqq_status='AVAILABLE'
                if qqq is not None:
                    try:
                        f.update(features_qqq(qqq,day,dec,offset))
                        f['btc_qqq_divergence']=f['btc_ret_48']-f['qqq_premarket']
                    except Exception as e:
                        qqq_status='UNAVAILABLE: '+str(e)[:100]
                else:qqq_status='UNAVAILABLE'
                record['phases'][phase]={'status':'SCORED','decision_ny':dec.isoformat(),
                    'candle_end_utc':candle,'entry_btc_price':entry,
                    'qqq_status':qqq_status,'scores':classify(phase,f)}
            except Exception as e:
                record['phases'][phase]={'status':'PENDING_DATA','reason':str(e)[:140]}
        if now>=target and btc.index.max()>=pd.Timestamp(target):
            outcome=float(btc.loc[btc.index<=pd.Timestamp(target)].iloc[-1].close)
            for phase,info in record['phases'].items():
                if info.get('status')!='SCORED':continue
                change=outcome/info['entry_btc_price']-1
                truth='LONG' if change>0 else ('SHORT' if change<0 else 'FLAT')
                info['settlement']={'target_btc_price':outcome,
                      'return':round(change,8),'truth':truth}
                for m in info['scores'].values():
                    if m.get('signal') in ('LONG','SHORT'):
                        m['correct']=m['signal']==truth
    write_json(saved,record)
    write_json(output/'latest.json',record)
    print('SAVED',saved,'PHASES',list(record['phases']),record['btc_status'],record['qqq_status'])
    return record

if __name__=='__main__':
    ap=argparse.ArgumentParser()
    ap.add_argument('--now',help='UTC ISO simulated now, requires dry-run')
    ap.add_argument('--dry-run',action='store_true')
    a=ap.parse_args()
    if a.now and not a.dry_run:ap.error('--now allowed only with --dry-run')
    now=datetime.fromisoformat(a.now.replace('Z','+00:00')) if a.now else None
    out=ROOT/'preview_data' if a.dry_run else ROOT/'docs/data'
    run(now,output=out)
