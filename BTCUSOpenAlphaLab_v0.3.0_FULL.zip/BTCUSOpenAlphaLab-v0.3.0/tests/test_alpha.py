import io
import json
import zipfile
from zoneinfo import ZoneInfo

import exchange_calendars as xc
import numpy as np
import pandas as pd
import pytest

from alpha_lab.data import _normalize_epoch, load_btc, load_qqq, data_quality, months_between
from alpha_lab.events import _btc_at, build_events
from alpha_lab.model import _signals, analyze
from alpha_lab.__main__ import _synthetic_events


def test_binance_milliseconds_microseconds():
    s = pd.Series([1700000000000, 1700000000000000],dtype='int64')
    dates = _normalize_epoch(s)
    assert dates[0] == dates[1]
    assert str(dates[0].tz) == 'UTC'


def test_month_range():
    assert months_between('2025-12','2026-02') == ['2025-12','2026-01','2026-02']
    with pytest.raises(ValueError):months_between('2026-03','2026-02')


def test_us_dst_calendar_open():
    cal = xc.get_calendar('XNYS')
    fri=cal.session_open(pd.Timestamp('2026-03-06'))
    mon=cal.session_open(pd.Timestamp('2026-03-09'))
    assert fri.hour == 14 and mon.hour == 13
    assert not cal.is_session(pd.Timestamp('2026-03-08'))


def test_read_binance_zip_and_gap_handling(tmp_path):
    cols=[]
    for i in [0,1,2,5,6]:
        t=int(pd.Timestamp('2026-01-05T00:00:00Z').timestamp()*1_000_000)+i*300_000_000
        cols.append(f'{t},100,102,99,{100+i},5,0,500,4,1,250,0')
    with zipfile.ZipFile(tmp_path/'BTCUSDT-5m-2026-01.zip','w') as z:
        z.writestr('BTCUSDT-5m-2026-01.csv','\n'.join(cols))
    data=load_btc(tmp_path,'2026-01','2026-01')
    assert len(data) == 5
    assert data.index.tz is not None
    assert {'btc_ret_12', 'btc_ret_48', 'btc_ret_96'} <= set(data.columns)
    assert np.isnan(data.iloc[3]['ret5'])


def test_qqq_premarket_30m_not_lookahead(tmp_path):
    # Extremely high 09:00 value is from unfinished 09:00..09:30 30m bar.
    csv='unique_id,ds,Open,High,Low,Close\n'
    for day in ['2026-03-06','2026-03-09']:
        rows=[('08:00',100),('08:30',101),('09:00',999),('09:30',103),
              ('09:35',104),('09:40',105)]
        for clock,close in rows:
            csv+=f'QQQ,{day} {clock}:00,{close},{close},{close},{close}\n'
    path=tmp_path/'qqq.csv';path.write_text(csv)
    q=load_qqq(path,interval='auto')
    day=q.loc[q.day==pd.Timestamp('2026-03-09').date()]
    unfinished=day[day.start_ny.dt.strftime('%H:%M')=='09:00'].iloc[0]
    assert unfinished.name.strftime('%H:%M')=='09:30'
    decision=pd.Timestamp('2026-03-09 09:15',tz='America/New_York')
    known=day.loc[day.index<=decision]
    assert known.iloc[-1]['close']==101
    assert 999 not in known['close'].to_list()


def test_btc_at_refuses_old_candle():
    when=pd.Timestamp('2026-03-09 09:15',tz='America/New_York')
    index=pd.DatetimeIndex([when.tz_convert('UTC')-pd.Timedelta(minutes=10)])
    df=pd.DataFrame({'close':[2.]},index=index)
    assert _btc_at(df,when) is None


def test_signals_and_no_trade():
    p=np.array([0.9,0.51,0.12])
    assert _signals(p,0.60).tolist() == [1,0,-1]
    assert _signals(p,None).tolist() == [0,0,0]


def test_synthetic_end_to_end_and_strict_holdout():
    ev=_synthetic_events()
    result=analyze(ev,data_mode='SYNTHETIC_ONLY')
    assert result['data_mode']=='SYNTHETIC_ONLY'
    assert result['events_total']>2000
    assert set(result['markets'])=={'pre15','post05','post30'}
    for market in result['markets'].values():
        assert market['test_count'] > 100
        assert market['train_count'] > market['validation_count']
        assert market['models']['M1_BTC']['status']=='tested'
        assert market['models']['M2_BTC_QQQ']['status']=='tested'
        assert market['models']['M3_BTC_QQQ_TAPE']['status']=='tested'
        assert market['models']['M1_BTC']['test']==market['test_count']


def test_missing_qqq_must_not_be_imputed_in_m2():
    ev=_synthetic_events()
    ev.loc[ev.phase=='post05','qqq_premarket']=np.nan
    result=analyze(ev,data_mode='SYNTHETIC_ONLY')
    m=result['markets']['post05']['models']
    assert m['M1_BTC']['status']=='tested'
    assert m['M2_BTC_QQQ']['status']=='insufficient complete feature rows'


def test_no_future_label_in_features():
    from alpha_lab.model import FEATURE_SETS
    all_columns=sum(FEATURE_SETS.values(),[])
    assert not set(['up','future_close','hold_return','close_ny','session']) & set(all_columns)


def test_full_event_builder_and_data_quality(tmp_path):
    # Deliberately constructed 5m bars over several NYSE sessions.
    from alpha_lab.data import data_quality
    times=pd.date_range('2026-03-05 00:05+00:00', '2026-03-12 00:00+00:00',freq='5min')
    n=len(times)
    btc=pd.DataFrame(index=times)
    btc['close']=np.linspace(100,110,n)
    for f in ('btc_ret_12','btc_ret_48','btc_ret_96','vol_60','buy_imbalance','volume_boost'):
        btc[f]=0.001
    records=['ds,Open,High,Low,Close']
    for day in ['2026-03-05','2026-03-06','2026-03-09','2026-03-10','2026-03-11']:
        for tm,price in [('08:00',99),('08:30',100),('09:00',777),
                         ('09:30',101),('09:35',102),('09:40',103),
                         ('10:00',104),('15:55',105)]:
            records.append(f'{day} {tm}:00,{price},{price},{price},{price}')
    p=tmp_path/'q.csv'; p.write_text('\n'.join(records))
    q=load_qqq(p)
    quality=data_quality(btc,q)
    assert quality['btc_bars']==n
    assert 30 in quality['qqq_bar_duration_min']
    events=build_events(btc,q)
    assert not events.empty
    mar9=events[events.session=='2026-03-09']
    assert set(mar9.phase)=={'pre15','post05','post30'}
    before=mar9.loc[mar9.phase=='pre15'].iloc[0]
    assert before.qqq_rth==0.0
    assert abs(before.qqq_premarket-(100/105-1))<1e-12
    assert before.decision_ny.startswith('2026-03-09T09:15')
    assert before.close_ny.startswith('2026-03-09T11:30')
