"""Cloud engine safety tests. No live HTTP required."""
import json
from datetime import datetime, timedelta, timezone
import numpy as np
import pandas as pd

from live_cloud.engine import (
    btc_bars, features_btc, classify, session_at, run, NY
)


def synthetic_bars(now):
    idx=pd.date_range(end=now, periods=900, freq="5min",tz="UTC")
    seq=np.arange(len(idx))
    return pd.DataFrame({"close":80000+seq*.5,
        "quote":np.full(len(idx),2e6),
        "buy":np.full(len(idx),1e6)},index=idx)


def test_dst_shift_and_us_market_holiday():
    summer=session_at(datetime(2026,10,9,14,20,tzinfo=timezone.utc))
    winter=session_at(datetime(2026,12,9,15,20,tzinfo=timezone.utc))
    assert summer[1].astimezone(timezone.utc).hour==13
    assert winter[1].astimezone(timezone.utc).hour==14
    assert session_at(datetime(2026,12,25,14,20,tzinfo=timezone.utc)) is None


def test_btc_features_are_fixed_and_do_not_look_ahead():
    decision=pd.Timestamp("2026-10-08T14:00:00Z")
    frame=synthetic_bars(decision+timedelta(hours=2))
    current=frame.loc[frame.index<=decision]
    f,price,end=features_btc(frame,decision)
    assert price==float(current.iloc[-1].close)
    assert abs(f["buy_imbalance"])<1e-12
    assert abs(f["volume_boost"]-1)<1e-12
    # Modify future prices drastically, earlier prediction must stay the same.
    changed=frame.copy()
    changed.loc[changed.index>decision,"close"]=1e12
    f2,p2,t2=features_btc(changed,decision)
    assert f==f2 and price==p2 and end==t2


def test_no_stale_candle():
    decision=pd.Timestamp("2026-10-08T14:00:00Z")
    frame=synthetic_bars(decision-timedelta(minutes=15))
    import pytest
    with pytest.raises(ValueError,match="not available"):
        features_btc(frame,decision)


def test_models_emit_three_valid_probabilities_with_btc_only():
    now=pd.Timestamp("2026-10-08T14:00:00Z")
    f,_,_=features_btc(synthetic_bars(now),now)
    scores=classify("pre15",f)
    assert scores["M1_BTC"]["status"]=="experimental"
    assert abs(scores["M1_BTC"]["prob_up"]+scores["M1_BTC"]["prob_down"]-1)<1e-5
    assert scores["M2_BTC_QQQ"]["status"]=="unavailable"
    assert scores["M3_BTC_QQQ_TAPE"]["status"]=="unavailable"


def test_freeze_predictions_when_later_market_data_changes(monkeypatch,tmp_path):
    import live_cloud.engine as engine
    now1=datetime(2026,10,8,13,20,tzinfo=timezone.utc)
    now2=datetime(2026,10,8,13,40,tzinfo=timezone.utc)
    now3=datetime(2026,10,8,14,5,tzinfo=timezone.utc)
    bars=synthetic_bars(pd.Timestamp(now3)+timedelta(hours=1))
    monkeypatch.setattr(engine,"btc_bars",lambda:bars)
    monkeypatch.setattr(engine,"qqq_bars",lambda: (_ for _ in ()).throw(ValueError("QQQ down")))
    first=run(now1,output=tmp_path)
    assert set(first["phases"])=={"pre15"}
    assert first["phases"]["pre15"]["scores"]["M1_BTC"]["status"]=="experimental"
    before=first["phases"]["pre15"]
    second=run(now2,output=tmp_path)
    assert set(second["phases"])=={"pre15","post05"}
    assert second["phases"]["pre15"]==before
    third=run(now3,output=tmp_path)
    assert set(third["phases"])=={"pre15","post05","post30"}
    assert third["phases"]["pre15"]==before
    assert third["phases"]["post30"]["scores"]["M2_BTC_QQQ"]["status"]=="unavailable"
    assert (tmp_path/"latest.json").exists()
    assert json.loads((tmp_path/"latest.json").read_text(encoding="utf-8"))["session"]=="2026-10-08"


def test_late_run_must_not_backfill_predicted_signal(monkeypatch,tmp_path):
    import live_cloud.engine as engine
    now=datetime(2026,10,8,14,5,tzinfo=timezone.utc)
    monkeypatch.setattr(engine,"btc_bars",lambda:synthetic_bars(pd.Timestamp(now)))
    monkeypatch.setattr(engine,"qqq_bars",lambda: (_ for _ in ()).throw(ValueError("QQQ down")))
    out=run(now,output=tmp_path)
    assert out["phases"]["pre15"]["status"]=="MISSED_WINDOW"
    assert out["phases"]["post05"]["status"]=="MISSED_WINDOW"
    assert out["phases"]["post30"]["status"]=="SCORED"
