"""Matched-sample and walk-forward regression tests."""
import numpy as np
import pandas as pd

from alpha_lab.__main__ import _synthetic_events
from alpha_lab.robustness import (
    FOLDS, MODEL_NAMES, _paired_comparison, _partition,
    analyze_robustness, matched_sessions,
)


def test_common_sample_filters_each_model_equally():
    events = _synthetic_events()
    events = events.loc[events.phase == "pre15"].copy()
    event = events.iloc[0]
    events.loc[event.name, "qqq_premarket"] = np.nan
    retained = matched_sessions(events, "pre15")
    assert len(retained) == len(events) - 1
    assert event.session not in set(retained.session)
    assert not retained.session.duplicated().any()


def test_walk_forward_folds_never_use_future_test_rows_for_training():
    events = _synthetic_events()
    phase = matched_sessions(events, "pre15")
    for spec in FOLDS:
        train, val, test = _partition(phase, spec)
        assert train.session.max() < val.session.min()
        assert val.session.max() < test.session.min()
        assert set(train.session).isdisjoint(test.session)
        assert set(val.session).isdisjoint(test.session)


def test_exact_paired_same_predictions_have_no_advantage():
    frame = pd.DataFrame({
        "up": [1, 0, 1, 0, 1, 0],
        "prob_M1_BTC": [.5, .7, .2, .1, .6, .5],
        "prob_M2_BTC_QQQ": [.5, .7, .2, .1, .6, .5],
    })
    result = _paired_comparison(frame, "M2_BTC_QQQ", "M1_BTC")
    assert result["accuracy_advantage_pp"] == 0
    assert result["mcnemar_exact_p"] == 1
    assert result["brier_advantage_vs_reference"] == 0
    assert result["accuracy_95pct_bootstrap_CI_pp"] == [0, 0]


def test_matched_walk_forward_pipeline_is_comparable_and_serializable(tmp_path):
    events = _synthetic_events()
    events = events.loc[events.phase == "pre15"].copy()
    events.loc[events.session == "2025-03-07", "qqq_premarket"] = np.nan
    report, pred = analyze_robustness(events)
    result = report["phases"]["pre15"]
    assert result["discarded_due_to_incomplete_features"] == 1
    assert result["aggregated_test_n"] == len(pred)
    assert len(pred) > 100
    assert all(result["folds"][f["name"]]["status"] == "evaluated" for f in FOLDS)
    assert set(MODEL_NAMES) == set(result["common_sample_models"])
    assert pred.groupby("session").size().max() == 1
    for name in MODEL_NAMES:
        assert pred[f"prob_{name}"].between(0, 1).all()
        assert len(pred[f"prob_{name}"]) == len(pred)
    from alpha_lab.robustness import write_robustness
    import json
    write_robustness(report, pred, tmp_path)
    assert "2026_Q1" in (tmp_path / "ROBUSTNESS_REPORT.md").read_text(encoding="utf-8")
    json.loads((tmp_path / "ROBUSTNESS.json").read_text(encoding="utf-8"))
