# BTC US Open Alpha Lab v0.4.0 — Cloudflare 即時架構

**沒有 GitHub Actions 更新行情，也沒有 GitHub Actions 自動提交 JSON。**
GitHub Pages **只託管靜態網頁**。所有即時價格、九組模型推論與固定時點快照都由獨立 Cloudflare Worker 提供。

## 首次部署（必需兩個平台）
### 1. Cloudflare Worker / KV
- Node.js 18+；進入 `worker` 資料夾。
- 執行 `npm install`，`npx wrangler login`（使用自己的 Cloudflare 帳戶授權）。
- 執行 `npx wrangler kv namespace create SNAPSHOTS`，複製輸出的 namespace ID。
- 編輯 `worker/wrangler.toml`，將 `REPLACE_WITH_YOUR_KV_NAMESPACE_ID` 改成真實 ID。
- 執行 `npm run deploy`。
- 打開部署結果 `https://...workers.dev/health`：應為 `{"ok":true,"version":"0.4.0","persistence":true,...,"github_actions":false}`。
- Cloudflare Worker 有每分鐘 Cron **嘗試**在 13:00–17:59 UTC 觸發；真正的固定預測時間由 Worker 按紐約時間換算。

### 2. GitHub Pages（無 Actions）
- 新建公開 repo：`BTCUSOpenAlphaLab`，把完整包解壓後的**內容**上傳 `main` 根目錄。
- Settings → Pages → Build and deployment → Source 選 **Deploy from a branch**，Branch 選 `main`，Folder 選 `/docs`，按 Save。
- 進入自己的 GitHub Pages 網址，在畫面欄位貼上 Cloudflare Worker `https://...workers.dev` 網址，按「連線 Worker」。
- 每 10 秒由瀏覽器直接從 Worker 取得市場現價；固定時點由 Worker 在 Cloudflare KV 保留結果。

## 核心功能
- 21:15、21:35、22:00 台灣夏令時間；冬令時間自動順延 1 小時。
- 3 個預測時點 x M1 BTC、M2 BTC+QQQ、M3 BTC+QQQ+Tape 共 9 組 XGBoost 模型。
- Binance BTCUSDT 現貨即時價格、5M K 線，Yahoo QQQ 五分鐘資料（可能延遲或無法取回）。
- QQQ 缺漏時 M2/M3 不顯示機率，並保留 M1 BTC-only。
- Worker Cron 提供**關閉瀏覽器時**的背景快照嘗試；網頁開著時每 10 秒直接向 Worker 更新。
- 15 分鐘預測時窗外沒有準時觀測的訊號標記 `MISSED_WINDOW`，絕不以事後資料偽造前向預測。
- 到 11:30 ET 計算各固定時點至相同終點的實際漲跌。
- `/api/history?day=YYYY-MM-DD` 取得已記錄的日期快照。

## 重要限制
- **Cloudflare Cron 也無法保證秒級準點或零漏執行**；網頁直接呼叫 Worker 不需要等待排程，但斷網或 Worker/資料源故障仍會漏訊。
- 必須完成 Worker、KV 與 GitHub Pages 三者的實際設定才會在雲端工作；只有上傳 GitHub ZIP 不夠。
- BTC/QQQ 模型由 2023–2026 Q1 歷史資料訓練；原先的共同樣本驗證沒有穩定超越基準。僅供與 BTCFLOWPulse 對照，不適合直接下單。
- 這套只觀察歷史已完成 5m K 線，現價欄位每十秒更新；模型不是每 10 秒重新訓練。
- 現有舊倉庫如果曾上傳 `.github/workflows/live.yml`，請在 GitHub 刪除此檔。v0.4.0 完整壓縮包**沒有任何 workflow**。

## 測試
- 本機 `py -3 run_qa_v0.4.0.py`（需要 Python、Node.js 和 requirements.txt）。
- Worker 單獨 `node --test worker/test/worker.test.mjs`。
- 歷史模型驗證輸入 `worker/test/fixtures.json`，包含 27 筆原生 Python XGBoost 預期機率。
- 歷史報告在 `docs/research.html`，檔案 `docs/data/robustness.json`。

詳細部署參考 `worker/README.md`。不要把 Cloudflare API Token 或帳戶憑證上傳到 GitHub。
