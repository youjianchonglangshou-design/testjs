# v0.4.0 — GitHub Actions 排程完全移除

2026-10-09

### 架構更正
- 移除舊版 `.github/workflows/live.yml`（不隨新包交付）。
- Github Pages 僅當靜態前端。更新原理：瀏覽器每 10 秒直接 `GET /api/live`。
- 改為 Cloudflare Worker + Cloudflare KV 做固定時間預測、收盤結算與留存；Cloudflare Cron 每分鐘為關閉瀏覽器時的備援。
- 如 Cron 延遲而超過固定時點 15 分鐘，顯示 MISSED_WINDOW，不能用後來的 K 線回填成預測。
- 將九組原始 Python XGBoost 模型匯出成 Worker 可直接在 V8 運算的 140 棵樹模型結構，無 Python 雲端執行排程。
- Github Pages 初次需填入 Worker workers.dev URL；不同裝置需要各貼一次，Cloudflare KV 保留資料跨裝置。

### 真正的測試
- Python 21 項全部通過。
- Worker Node 4 項全部通過。
- 27 組歷史樣本對照原始 XGBoost 推論結果全部通過。
- 頁面 JS 語法與 ZIP 完整性檢查。

### 尚未完成
- Cloudflare 帳戶綁定 / KV 建立 / Worker 實際部署，需要使用者自己的 Cloudflare 權限登入操作；沒有這些不能聲稱今晚已正式線上可用。
- Github Pages 正式部署需要存在相應儲存庫並啟用 Pages。
- Yahoo Finance 從 Cloudflare 機房是否可用，仍需實際部署後確認；失敗時不猜 M2/M3。
- 即使 Cloudflare 定期排程一般較適合做伺服器背景工作，也不能承諾絕對不延遲。
