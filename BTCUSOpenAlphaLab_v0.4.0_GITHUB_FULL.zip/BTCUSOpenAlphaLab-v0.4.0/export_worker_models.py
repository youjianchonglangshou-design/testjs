"""Export XGBoost compact tree structures for native Cloudflare Worker JS inference."""
from pathlib import Path
import json,math
root=Path(__file__).resolve().parent
manifest=json.loads((root/'live_models/manifest.json').read_text(encoding='utf-8'))
out={'metadata':{'model_train_end':manifest['train_end'],'calibration_start':manifest['calibration_start'],'version':'0.4.0'},'phases':{}}
for phase,models in manifest['models'].items():
    out['phases'][phase]={}
    for name,info in models.items():
        full=json.loads((root/'live_models'/info['filename']).read_text(encoding='utf-8'))
        learner=full['learner']
        score=float(learner['learner_model_param']['base_score'].strip('[]'))
        trees=[]
        for t in learner['gradient_booster']['model']['trees']:
            trees.append([t['split_indices'],t['split_conditions'],t['left_children'],t['right_children'],t['default_left']])
        out['phases'][phase][name]={'columns':info['columns'],
          'calibration_coefficient':info['calibration_coefficient'],
          'calibration_intercept':info['calibration_intercept'],
          'base_margin':math.log(score/(1-score)),
          'trees':trees}
dest=root/'worker/src/models.mjs'
dest.write_text('export const MODELS='+json.dumps(out,separators=(',',':'))+';\n',encoding='utf-8')
print('EXPORTED_MODELS',len(manifest['models'])*3,'BYTES',dest.stat().st_size)
