"""Validate native JS XGBoost inference against original Python XGBoost artifacts."""
import json,math
from pathlib import Path
import numpy as np
import pandas as pd
import xgboost as xgb
ROOT=Path(__file__).resolve().parent
manifest=json.loads((ROOT/'live_models/manifest.json').read_text(encoding='utf-8'))
events=pd.read_csv(ROOT/'reports/events.csv')
tests=[]
for phase,models in manifest['models'].items():
    data=events[(events.phase==phase)&(events.session>'2025-06-30')].copy()
    for name,entry in models.items():
        cols=entry['columns']
        valid=data.dropna(subset=cols)
        # 3 distinct historical examples; NO publishing past values as live predictions.
        for _,row in valid.iloc[[0,len(valid)//2,-1]].iterrows():
            f={k:float(row[k]) for k in cols}
            model=xgb.Booster()
            model.load_model(str(ROOT/'live_models'/entry['filename']))
            d=xgb.DMatrix(np.array([[f[x] for x in cols]]),feature_names=cols)
            raw=float(model.predict(d)[0])
            logit=math.log(raw/(1-raw))
            p=1/(1+math.exp(-(entry['calibration_coefficient']*logit+entry['calibration_intercept'])))
            tests.append({'phase':phase,'model':name,'features':f,'expected':p,'raw':raw})
target=ROOT/'worker/test/fixtures.json'
target.write_text(json.dumps(tests,separators=(',',':')),encoding='utf-8')
print('PYTHON_PARITY_FIXTURES',len(tests), 'file bytes',target.stat().st_size)
