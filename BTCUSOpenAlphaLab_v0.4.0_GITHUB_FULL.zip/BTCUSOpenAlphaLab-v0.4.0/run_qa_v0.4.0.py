from pathlib import Path
import subprocess,sys
root=Path(__file__).resolve().parent
commands=[['node','--check',str(root/'worker/src/index.mjs')],
          ['node','--test',str(root/'worker/test/worker.test.mjs')],
          [sys.executable,'-m','pytest','-q','--disable-warnings']]
for args in commands:
    print('RUN',*args,flush=True)
    proc=subprocess.run(args,cwd=root,text=True,encoding='utf-8',errors='replace',stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    print(proc.stdout.encode('ascii','backslashreplace').decode('ascii'),flush=True)
    if proc.returncode: raise SystemExit(proc.returncode)
print('ALL_QA_PASSED')
