# Cloudflare Worker：BTC US Open Alpha v0.4.0

**本專案不使用 GitHub Actions 做即時更新，也不需要 GitHub 自動 commit JSON。**

## 部署（只設定一次）

1. Cloudflare 帳戶登入後，電腦安裝 Node.js；在本 `worker` 資料夾執行 `npm install`、`npx wrangler login`。
2. 執行 `npx wrangler kv namespace create SNAPSHOTS`，取得 Cloudflare KV namespace ID。
3. 在 `wrangler.toml` 的 `id = "REPLACE_WITH_YOUR_KV_NAMESPACE_ID"` 填上剛剛的 ID。
4. 執行 `npm run deploy`；Wrangler 會回報正式的 `https://...workers.dev` URL。
5. 將 GitHub Pages `docs/index.html` 內容部署在 `main /docs`（Pages Source 選 **Deploy from a branch**，不要選 GitHub Actions）。
6. 到網頁貼上你的 Worker 完整網址，按「連線 Worker」。每 10 秒更新即時 BTC 現價；固定預測時間由 Worker 算完寫入 Cloudflare KV。
7. 測試 `WORKER_URL/health`，應回報 `github_actions: false`、`persistence: true`。
8. 在 Cloudflare Worker Settings / Triggers 確認 Cron 已部署：`* 13-17 * * 1-5`（UTC，含夏冬令開盤前後時段）。

## 架構

GitHub Pages（網頁靜態版） → Cloudflare Worker `/api/live`（即時請求）
以及 Cloudflare Cron（每分鐘**嘗試**排程）→ Worker 交易日 K 線擷取與模型推理 → Cloudflare KV 保存 immutable 預測快照。

雲端排程無法保證每秒精準。15 分鐘內若 Worker 沒取得數據，標記 `MISSED_WINDOW`，不能事後回填為即時預測。兩者都不開網頁且 Cron 不執行時，可能錯過訊號；此系統不保證絕對不漏訊號。

JSON：`/api/live` 即時狀態，`/api/history?day=YYYY-MM-DD` 歷史當天，`/health` 部署健康狀態。

公開資料 Binance BTCUSDT / Yahoo QQQ（Yahoo 並非官方 SIP，可能被限制；不可用時 M2/M3 顯示資料不足）。
