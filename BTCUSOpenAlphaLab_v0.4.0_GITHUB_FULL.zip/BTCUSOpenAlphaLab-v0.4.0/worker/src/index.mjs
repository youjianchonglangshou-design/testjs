import { MODELS } from './models.mjs';

// Independent Cloudflare Worker: Cron for closed-browser snapshots,
// on-demand requests from GitHub Pages for immediate updates.
// GitHub Actions is deliberately not involved in price updates.
const VER='0.4.0';
const PHASES={pre15:-15,post05:5,post30:30};
const PERIOD=300000;
const DATE_FMT=new Intl.DateTimeFormat('en-US',{timeZone:'America/New_York',year:'numeric',month:'2-digit',day:'2-digit'});
const OFFSET_FMT=new Intl.DateTimeFormat('en-US',{timeZone:'America/New_York',timeZoneName:'shortOffset'});
const httpJson = (data,status=200)=>new Response(JSON.stringify(data),{
  status,headers:{'content-type':'application/json; charset=utf-8',
    'access-control-allow-origin':'*','cache-control':'no-store, max-age=0',
    'access-control-allow-methods':'GET,OPTIONS',
    'access-control-allow-headers':'content-type'}});
const sigmoid=z=>1/(1+Math.exp(-Math.max(-80,Math.min(80,z))));
const finite=x=>typeof x==='number'&&Number.isFinite(x);
const round=(x,d=6)=>Math.round(x*10**d)/10**d;
const formatDay=now=>{const parts=DATE_FMT.formatToParts(now);const read=k=>parts.find(p=>p.type===k)?.value;
  return [read('year'),read('month'),read('day')].join('-')};
function isoUTC(date){return date.toISOString().slice(0,10)}
function nthWeekday(year,month,weekday,n){
  const first=new Date(Date.UTC(year,month-1,1)).getUTCDay();
  return isoUTC(new Date(Date.UTC(year,month-1,1+(weekday-first+7)%7+(n-1)*7)));
}
function lastWeekday(year,month,weekday){
  const last=new Date(Date.UTC(year,month,0));
  return isoUTC(new Date(Date.UTC(year,month-1,last.getUTCDate()-(last.getUTCDay()-weekday+7)%7)));
}
function observed(year,month,day){
  const d=new Date(Date.UTC(year,month-1,day));
  if(d.getUTCDay()===6)d.setUTCDate(d.getUTCDate()-1);
  if(d.getUTCDay()===0)d.setUTCDate(d.getUTCDate()+1);
  return isoUTC(d);
}
function easter(year){
  const a=year%19,b=Math.floor(year/100),c=year%100,d=Math.floor(b/4),e=b%4,
  f=Math.floor((b+8)/25),g=Math.floor((b-f+1)/3),h=(19*a+b-d-g+15)%30,
  i=Math.floor(c/4),k=c%4,l=(32+2*e+2*i-h-k+7)%7,
  m=Math.floor((a+11*h+22*l)/451),n=Math.floor((h+l-7*m+114)/31),p=(h+l-7*m+114)%31+1;
  return new Date(Date.UTC(year,n-1,p));
}
function nyseHoliday(day){
  const y=Number(day.slice(0,4));
  for(const yr of [y,y+1]){
    const holidays=new Set([
      observed(yr,1,1),nthWeekday(yr,1,1,3),nthWeekday(yr,2,1,3),
      lastWeekday(yr,5,1),observed(yr,6,19),observed(yr,7,4),
      nthWeekday(yr,9,1,1),nthWeekday(yr,11,4,4),observed(yr,12,25)
    ]);
    const goodFriday=easter(yr);goodFriday.setUTCDate(goodFriday.getUTCDate()-2);
    holidays.add(isoUTC(goodFriday));
    if(holidays.has(day))return true;
  }
  return false;
}
function etSession(now){
  const day=formatDay(now);
  const weekday=new Date(day+'T12:00:00Z').getUTCDay();
  if(weekday===0||weekday===6||nyseHoliday(day))return null;
  const match=OFFSET_FMT.format(now).match(/GMT([+-]\d+)/);
  if(!match)throw Error('Cannot determine New York timezone offset');
  const offset=Number(match[1]);
  const open=Date.parse(day+'T09:30:00Z')-offset*3600000;
  const target=open+120*60000;
  return {day,open,target,phases:Object.fromEntries(Object.entries(PHASES).map(([k,v])=>[k,open+v*60000]))};
}
async function jsonFetch(url){
  const controller=new AbortController();
  const timeout=setTimeout(()=>controller.abort(),7000);
  try{
    const r=await fetch(url,{headers:{'accept':'application/json','user-agent':'Mozilla/5.0'},signal:controller.signal,cf:{cacheTtl:10}});
    if(!r.ok)throw Error('HTTP '+r.status);
    return await r.json();
  }finally{clearTimeout(timeout)}
}
async function btcBars(){
  const sources=['https://data-api.binance.vision/api/v3/klines?symbol=BTCUSDT&interval=5m&limit=500',
   'https://api.binance.com/api/v3/klines?symbol=BTCUSDT&interval=5m&limit=500'];
  let raw=null,errors=[];
  for(const u of sources){
    try{
      const result=await jsonFetch(u);
      if(Array.isArray(result)&&result.length>=300){raw=result;break}
      errors.push('invalid Binance payload');
    }catch(e){errors.push(e.message)}
  }
  if(!raw)throw Error('BTC 5m source unavailable: '+errors.join(', '));
  const bars=raw.map(r=>({
     t:Number(r[0])+PERIOD,close:Number(r[4]),volume:Number(r[7]),buy:Number(r[10])
  })).filter(r=>[r.t,r.close,r.volume,r.buy].every(finite)&&r.close>0);
  if(bars.length<300)throw Error('Insufficient complete BTC 5m data');
  bars.sort((a,b)=>a.t-b.t);
  return bars;
}
async function qqqBars(){
  const sources=['https://query1.finance.yahoo.com/v8/finance/chart/QQQ?interval=5m&range=5d&includePrePost=true',
      'https://query2.finance.yahoo.com/v8/finance/chart/QQQ?interval=5m&range=5d&includePrePost=true'];
  let errors=[];
  for(const u of sources){
    try{
      const j=await jsonFetch(u);
      const row=j?.chart?.result?.[0];
      const times=row?.timestamp,price=row?.indicators?.quote?.[0];
      if(!times||!price)throw Error('Empty QQQ series');
      const rows=times.map((t,i)=>({t:Number(t)*1000+PERIOD,open:Number(price.open?.[i]),
       close:Number(price.close?.[i]),start:Number(t)*1000}))
       .filter(r=>[r.t,r.open,r.close].every(finite)&&r.close>0);
      if(!rows.length)throw Error('Empty valid QQQ bars');
      return rows.sort((a,b)=>a.t-b.t);
    }catch(e){errors.push(e.message)}
  }
  throw Error('QQQ fetch failed: '+errors.join(' | '));
}
async function btcTicker(){
  const j=await jsonFetch('https://data-api.binance.vision/api/v3/ticker/price?symbol=BTCUSDT');
  const p=Number(j.price);
  if(!finite(p)||p<=0)throw Error('BTC ticker invalid');
  return p;
}
function btcFeatures(bars,when){
  const found=bars.filter(b=>b.t<=when);
  if(found.length<289||when-found.at(-1).t>600000)throw Error('BTC 5m history too old/short');
  const v=found.slice(-289),last=v.at(-1);
  for(let i=1;i<v.length;i++)if(v[i].t-v[i-1].t!==PERIOD)throw Error('BTC 5m gap');
  const c=v.map(b=>b.close),n=v.length;
  const returns=c.slice(-13).map((x,i,a)=>i?x/a[i-1]-1:null).slice(1);
  const mean=returns.reduce((a,b)=>a+b,0)/12;
  const std=Math.sqrt(returns.reduce((a,b)=>a+(b-mean)**2,0)/11);
  const tail=v.slice(-12),sum=(rows,key)=>rows.reduce((a,b)=>a+b[key],0);
  const volume12=sum(tail,'volume'),volume288=sum(v.slice(-288),'volume');
  if(volume12<=0||volume288<=0)throw Error('BTC volumes invalid');
  return {features:{
    btc_ret_12:c[n-1]/c[n-13]-1,
    btc_ret_48:c[n-1]/c[n-49]-1,
    btc_ret_96:c[n-1]/c[n-97]-1,
    vol_60:std,buy_imbalance:sum(tail,'buy')/volume12-0.5,
    volume_boost:(volume12/12)/(volume288/288)},
    entry_price:last.close,candle_end_utc:new Date(last.t).toISOString()};
}
function localETparts(timestamp){
  const parts=DATE_FMT.formatToParts(new Date(timestamp));
  const val=k=>parts.find(p=>p.type===k).value;
  const d=[val('year'),val('month'),val('day')].join('-');
  const ts=new Intl.DateTimeFormat('en-GB',{timeZone:'America/New_York',
    hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).format(new Date(timestamp));
  return {day:d,clock:ts};
}
function qqqFeatures(bars,session,decision,offset){
  // Yahoo provides 5m START stamps; end= start+5m. Never read open/incomplete bars.
  const dated=bars.map(b=>({...b,et:localETparts(b.start)}));
  const prev=dated.filter(b=>b.et.day<session.day&&b.et.clock>='15:40'&&b.et.clock<='15:55');
  if(!prev.length)throw Error('QQQ prior 15:55 close unavailable');
  const latestDay=prev.at(-1).et.day;
  if((Date.parse(session.day)-Date.parse(latestDay))/86400000>5)throw Error('QQQ previous close stale');
  const previous=prev.filter(b=>b.et.day===latestDay).at(-1).close;
  const available=dated.filter(b=>b.et.day===session.day&&b.t<=decision);
  const pm=available.filter(b=>b.et.clock>='04:00'&&b.et.clock<'09:30');
  if(!pm.length||decision-pm.at(-1).t>3600000)throw Error('QQQ premarket unavailable');
  let regular=0;
  if(offset>0){
    const rth=available.filter(b=>b.et.clock>='09:30');
    if(!rth.length||rth[0].et.clock!=='09:30'||decision-rth.at(-1).t>600000)
      throw Error('QQQ RTH 5m data not closed');
    regular=rth.at(-1).close/rth[0].open-1;
  }
  return {qqq_premarket:pm.at(-1).close/previous-1,qqq_rth:regular};
}
export function classify(phase,features){
  const out={};
  for(const [name,model] of Object.entries(MODELS.phases[phase])){
    const v=model.columns.map(k=>Math.fround(features[k]));
    if(v.some(x=>!finite(x))){out[name]={status:'UNAVAILABLE',reason:'Missing required features'};continue}
    let margin=model.base_margin;
    for(const tree of model.trees){
      const [idx,threshold,left,right,defaultLeft]=tree;
      let n=0;
      for(let guard=0;guard<30;guard++){
        if(left[n]===-1)break;
        n=!finite(v[idx[n]])?(defaultLeft[n]?left[n]:right[n]):
          (v[idx[n]]<Math.fround(threshold[n])?left[n]:right[n]);
      }
      if(n<0||left[n]!==-1)throw Error('Invalid XGBoost tree');
      margin+=threshold[n];
    }
    const raw=sigmoid(margin);
    const logit=Math.log(Math.max(1e-12,raw)/(1-Math.min(1-1e-12,raw)));
    const p=sigmoid(model.calibration_coefficient*logit+model.calibration_intercept);
    out[name]={status:'EXPERIMENTAL',prob_up:round(p),prob_down:round(1-p),
      signal:p>=.55?'LONG':p<=.45?'SHORT':'WAIT'};
  }
  return out;
}
function blank(session,now){return {
 version:VER,session:session.day,open_ny:new Date(session.open).toISOString(),
 target_ny:new Date(session.target).toISOString(),updated_utc:new Date(now).toISOString(),
 source:'Binance BTCUSDT spot; Yahoo QQQ unofficial delayed feed',
 model_train_end:MODELS.metadata.model_train_end,phase_status:{},
 phases:{},status:'PREOPEN'};
}
async function getSaved(env,key){
  const raw=await env.SNAPSHOTS.get(key);
  return raw?JSON.parse(raw):null;
}
async function calc(env,now,fromCron=false){
  if(!env.SNAPSHOTS)throw Error('KV binding SNAPSHOTS is missing: configure Cloudflare KV before deploying');
  const session=etSession(new Date(now));
  if(!session)return {version:VER,status:'NYSE_CLOSED',updated_utc:new Date(now).toISOString(),phases:{}};
  const key='open:'+session.day;
  const previous=await getSaved(env,key);
  const record=previous||blank(session,now);
  record.status=now<session.open?'PREOPEN':now<session.target?'OPEN':'SETTLED';
  let changed=!previous;
  const eligible=Object.entries(PHASES).filter(([phase])=>now>=session.phases[phase]);
  const needs=eligible.filter(([phase])=>!['SCORED','MISSED_WINDOW'].includes(record.phases?.[phase]?.status));
  const settle=now>=session.target&&!record.settled;
  let bars=null;
  if(needs.length||settle){
    try{bars=await btcBars()}catch(e){record.btc_status='UNAVAILABLE: '+e.message}
  }
  let qqq=null;
  if(needs.some(([phase])=>now-session.phases[phase]<=15*60000)&&bars){
    try{qqq=await qqqBars()}catch(e){record.qqq_status='UNAVAILABLE: '+e.message}
  }
  if(bars){
    record.btc_status='OK';
    for(const [phase,offset] of needs){
      const decision=session.phases[phase];
      if(now-decision>15*60000){
        record.phases[phase]={status:'MISSED_WINDOW',decision_utc:new Date(decision).toISOString(),
          reason:'No timely Cloudflare Worker run within 15 minutes'};
        changed=true;continue
      }
      try{
        const t=btcFeatures(bars,decision);
        const f=t.features;
        let status='UNAVAILABLE';
        if(qqq){
          try{const q=qqqFeatures(qqq,session,decision,offset);Object.assign(f,q);
            f.btc_qqq_divergence=f.btc_ret_48-f.qqq_premarket;status='OK'}
          catch(e){status='UNAVAILABLE: '+e.message}
        }
        const scores=classify(phase,f);
        record.phases[phase]={status:'SCORED',decision_utc:new Date(decision).toISOString(),
          generated_utc:new Date(now).toISOString(),qqq_status:status,
          entry_price:t.entry_price,candle_end_utc:t.candle_end_utc,scores};
        changed=true;
      }catch(e){record.phase_status[phase]='WAIT_DATA: '+e.message}
    }
    if(settle){
      try{
        const t=btcFeatures(bars,session.target);
        for(const phase of Object.keys(record.phases)){
          const info=record.phases[phase];
          if(info.status!=='SCORED')continue;
          const ret=t.entry_price/info.entry_price-1;
          const truth=ret>0?'LONG':ret<0?'SHORT':'FLAT';
          info.settlement={price:t.entry_price,return:round(ret,8),truth};
          for(const score of Object.values(info.scores)){
            if(score.signal==='LONG'||score.signal==='SHORT')score.correct=score.signal===truth;
          }
        }
        record.settled=true;changed=true;
      }catch(e){record.settlement_status='WAIT_DATA: '+e.message}
    }
  }
  if(changed){
    record.updated_utc=new Date(now).toISOString();
    await env.SNAPSHOTS.put(key,JSON.stringify(record));
  }
  // Inference snapshots persist unchanged. Current market tick is only a transient UI update.
  const output=structuredClone(record);
  output.checked_utc=new Date(now).toISOString();
  if(!fromCron){
    try{output.market_price=await btcTicker();output.market_price_utc=new Date().toISOString()}
    catch(e){output.market_price_status='UNAVAILABLE: '+e.message}
  }
  return output;
}
export default {
 async fetch(req,env,ctx){
   if(req.method==='OPTIONS')return httpJson({ok:true});
   if(req.method!=='GET')return httpJson({error:'Method not allowed'},405);
   const url=new URL(req.url);
   try{
     if(url.pathname==='/health')return httpJson({ok:true,version:VER,
       persistence:!!env.SNAPSHOTS,updater:'Cloudflare Worker Cron + on-demand',github_actions:false});
     if(url.pathname==='/api/live')return httpJson(await calc(env,Date.now()));
     if(url.pathname==='/api/history'){
       if(!env.SNAPSHOTS)throw Error('Missing SNAPSHOTS KV');
       const day=url.searchParams.get('day');
       if(!/^\d{4}-\d{2}-\d{2}$/.test(day||''))return httpJson({error:'day must be YYYY-MM-DD'},400);
       const saved=await getSaved(env,'open:'+day);
       return httpJson(saved||{status:'NOT_RECORDED',session:day},saved?200:404);
     }
     return httpJson({error:'Not found'},404);
   }catch(e){return httpJson({status:'ERROR',error:String(e.message||e),version:VER},503)}
 },
 async scheduled(evt,env,ctx){ctx.waitUntil(calc(env,Date.now(),true).catch(e=>console.error('scheduled failure',String(e))))}
};
