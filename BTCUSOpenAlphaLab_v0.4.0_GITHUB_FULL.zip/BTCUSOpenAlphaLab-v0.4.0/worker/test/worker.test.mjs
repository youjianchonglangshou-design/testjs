import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { classify } from '../src/index.mjs';
import worker from '../src/index.mjs';

test('27 exact historical feature rows: native Worker inference agrees with Python XGBoost',()=>{
  const fixtures=JSON.parse(fs.readFileSync(new URL('./fixtures.json',import.meta.url),'utf8'));
  assert.equal(fixtures.length,27);
  for(const f of fixtures){
    const scored=classify(f.phase,f.features)[f.model];
    assert.equal(scored.status,'EXPERIMENTAL');
    assert.ok(Math.abs(scored.prob_up-f.expected)<0.000004,
      f.phase+' '+f.model+' JS '+scored.prob_up+' PY '+f.expected);
  }
});

const batch=(day,startHour=8,endHour=20)=>{
  const out=[];
  for(let h=startHour;h<endHour;h++)for(let i=0;i<60;i+=5){
    const when=Date.parse(day+'T'+String(h).padStart(2,'0')+':'+String(i).padStart(2,'0')+':00Z');
    const p=600+(h*12+i/5)*0.04+(day.endsWith('09')?1:0);
    out.push([when,p,p+0.03]);
  }
  return out;
};
function mocks(){
  const originalFetch=globalThis.fetch;
  const open=Date.parse('2026-10-09T17:00:00Z')-500*300000;
  const binance=Array.from({length:500},(_,i)=>{
    const time=open+i*300000,close=81000+Math.sin(i/8)*30+i/4;
    return [time,String(close-2),0,0,String(close),4,0,'1000000',100,2,'500000',0];
  });
  const qqq=[...batch('2026-10-08'),...batch('2026-10-09')];
  const timestamps=qqq.map(x=>x[0]/1000);
  const yahoo={chart:{result:[{timestamp:timestamps,indicators:{quote:[{
    open:qqq.map(x=>x[1]),close:qqq.map(x=>x[2])
  }]}}]}};
  globalThis.fetch=async function(url){
    const target=String(url);
    let payload;
    if(target.includes('/api/v3/klines'))payload=binance;
    else if(target.includes('/ticker/price'))payload={price:'81321.45'};
    else if(target.includes('finance.yahoo.com'))payload=yahoo;
    else throw Error('Unexpected network '+target);
    return new Response(JSON.stringify(payload),{status:200,headers:{'content-type':'application/json'}});
  };
  return ()=>{globalThis.fetch=originalFetch};
}
const memory=()=>{const store=new Map();return {SNAPSHOTS:{
  async get(k){return store.get(k)||null},async put(k,v){store.set(k,v)}
}}};
async function at(time,env){
  const original=Date.now;Date.now=()=>Date.parse(time);
  try{
    const res=await worker.fetch(new Request('https://example.workers.dev/api/live'),env,{});
    const body=await res.json();assert.equal(res.status,200,JSON.stringify(body));
    return body;
  }finally{Date.now=original}
}

test('Worker on-demand freezes timely phases, survives later calls and settles',async()=>{
  const restore=mocks(),env=memory();
  try{
    const a=await at('2026-10-09T13:20:00Z',env);
    assert.equal(a.phases.pre15.status,'SCORED');
    assert.equal(a.phases.pre15.scores.M1_BTC.status,'EXPERIMENTAL');
    assert.equal(a.phases.pre15.scores.M2_BTC_QQQ.status,'EXPERIMENTAL');
    const locked=JSON.stringify(a.phases.pre15);
    const b=await at('2026-10-09T13:40:00Z',env);
    assert.equal(b.phases.post05.status,'SCORED');
    assert.equal(JSON.stringify(b.phases.pre15),locked);
    const c=await at('2026-10-09T14:05:00Z',env);
    assert.equal(c.phases.post30.status,'SCORED');
    assert.equal(JSON.stringify(c.phases.pre15),locked);
    const d=await at('2026-10-09T15:35:00Z',env);
    assert.equal(d.settled,true);
    assert.ok(typeof d.phases.pre15.settlement.return==='number');
    assert.equal(d.market_price,81321.45);
  }finally{restore()}
});

test('Late first access marks missed, never backfills false live signals',async()=>{
  const restore=mocks(),env=memory();
  try{
    const late=await at('2026-10-09T14:05:00Z',env);
    assert.equal(late.phases.pre15.status,'MISSED_WINDOW');
    assert.equal(late.phases.post05.status,'MISSED_WINDOW');
    assert.equal(late.phases.post30.status,'SCORED');
    const tomorrow=await worker.fetch(new Request('https://example.workers.dev/health'),env,{});
    const health=await tomorrow.json();
    assert.equal(health.github_actions,false);
    assert.equal(health.persistence,true);
  }finally{restore()}
});

test('Missing KV binding fails safely instead of publishing non-persistent snapshots',async()=>{
  const res=await worker.fetch(new Request('https://example.workers.dev/api/live'),{},{});
  assert.equal(res.status,503);
  const data=await res.json();
  assert.match(data.error,/SNAPSHOTS/);
});

test('NYSE Christmas, observed Independence Day and Good Friday never publish forecasts',async()=>{
 const env=memory();
 for(const instant of ['2026-12-25T14:00:00Z','2026-07-03T13:20:00Z','2026-04-03T13:20:00Z']){
   const result=await at(instant,env);
   assert.equal(result.status,'NYSE_CLOSED',instant);
   assert.deepEqual(result.phases,{});
 }
});
